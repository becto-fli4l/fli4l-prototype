/* version.h ..... keep track of package version number. 
 *                 C. Scott Ananian <cananian@alumni.princeton.edu>
 *
 * $Id: version.h,v 1.1 1997/12/16 11:35:20 cananian Exp $
 */

#ifndef INC_VERSION_H
#define INC_VERSION_H
extern const char * version;
#endif /* INC_VERSION_H */
