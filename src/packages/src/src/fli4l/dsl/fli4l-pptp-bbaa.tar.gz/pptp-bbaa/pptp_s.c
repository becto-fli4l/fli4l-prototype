
#define PPTP_SERVER 1
#include "pptp.c"
