/* version.c ..... keep track of package version number. 
 *                 C. Scott Ananian <cananian@alumni.princeton.edu>
 *
 * $Id: version.c,v 1.3 1997/12/16 11:47:23 cananian Exp $
 */

const char * version = "pptp-linux version " PPTP_LINUX_VERSION;
