/* inststr.h ..... change argv[0].
 *
 * $Id: inststr.h,v 1.1 1997/12/15 11:34:18 cananian Exp $
 */

void inststr(int argc, char **argv, char **envp, char *src);
