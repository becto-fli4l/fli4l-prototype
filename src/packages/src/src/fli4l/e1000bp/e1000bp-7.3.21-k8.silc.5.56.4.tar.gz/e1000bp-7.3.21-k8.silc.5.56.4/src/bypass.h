/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2004-2006 Silicom, Ltd                                       */
/* All rights reserved.                                                       */
/*                                                                            */
/* This program is free software; you can redistribute it and/or modify       */
/* it under the terms of the GNU General Public License as published by       */
/* the Free Software Foundation, located in the file LICENSE.                 */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/******************************************************************************/

#ifndef BYPASS_H
#define BYPASS_H

#include "bp_ioctl.h"


#define bp_lock(a)  if(!(in_interrupt())) \
        {if(down_interruptible(&(a)->bypass_lock)) return -1;} 

#define bp_unlock(a)  if(!(in_interrupt())) \
        up(&(a)->bypass_lock); 
    
#define bp_lock_init(a)  sema_init(&(a)->bypass_lock, 1);


/* HW related */

#define CTRL_EXT_MCLK_DIR   E1000_CTRL_EXT_SDP7_DIR
#define CTRL_EXT_MCLK_DATA  E1000_CTRL_EXT_SDP7_DATA
#define CTRL_EXT_MDIO_DIR   E1000_CTRL_EXT_SDP6_DIR
#define CTRL_EXT_MDIO_DATA  E1000_CTRL_EXT_SDP6_DATA


/* Bypass related */

struct ex_time {
    unsigned int hour;
    unsigned int min;
    unsigned int sec;
    unsigned int msec;
};
#define SYNC_CMD_VAL               2      /* 10b */
#define SYNC_CMD_LEN               2

#define WR_CMD_VAL                 2      /* 10b */
#define WR_CMD_LEN                 2 

#define RD_CMD_VAL                 1      /* 10b */
#define RD_CMD_LEN                 2 

#define ADDR_CMD_LEN               4 

#define WR_DATA_LEN                8
#define RD_DATA_LEN                8


#define PIC_SIGN_REG_ADDR          0x7
    #define PIC_SIGN_VALUE         0xcd


#define STATUS_REG_ADDR           0
    #define WDT_EN_MASK            0x01    //BIT_0
    #define CMND_EN_MASK           0x02    //BIT_1
    #define DIS_BYPASS_CAP_MASK    0x04    //BIT_2 /* Bypass Cap is disable*/
    #define DFLT_PWRON_MASK        0x08    //BIT_3
    #define BYPASS_OFF_MASK        0x10    //BIT_4
    #define BYPASS_FLAG_MASK       0x20    //BIT_5
    /*#define STD_NIC_MASK           (DIS_BYPASS_CAP_MASK | BYPASS_OFF_MASK | DFLT_PWRON_MASK)*/
    #define STD_NIC_MASK           DIS_BYPASS_CAP_MASK
    #define WD_EXP_FLAG_MASK       0x40    //BIT_6
    #define DFLT_PWROFF_MASK       0x80    //BIT_7   
    #define STD_NIC_PWOFF_MASK     (DIS_BYPASS_CAP_MASK | BYPASS_OFF_MASK | DFLT_PWRON_MASK | DFLT_PWROFF_MASK)
    
#define PRODUCT_CAP_REG_ADDR   0x5
    #define BYPASS_SUPPORT_MASK    0x01    //BIT_0
    #define TAP_SUPPORT_MASK       0x02    //BIT_1
    #define NORMAL_UNSUPPORT_MASK  0x04    /*BIT_2*/
    #define DISC_SUPPORT_MASK      0x08    //BIT_3
    #define TPL2_SUPPORT_MASK      0x10    //BIT_4


#define STATUS_TAP_REG_ADDR    0x6
    #define WDTE_TAP_BPN_MASK      0x01    //BIT_1 /* 1 when wdt expired -> TAP, 0 - Bypass */
    #define DIS_TAP_CAP_MASK       0x04    //BIT_2 /* TAP Cap is disable*/
    #define DFLT_PWRON_TAP_MASK    0x08    //BIT_3
    #define TAP_OFF_MASK           0x10    //BIT_4
    #define TAP_FLAG_MASK          0x20    //BIT_5
    /*#define STD_NIC_TAP_MASK       (DIS_TAP_CAP_MASK | TAP_OFF_MASK | DFLT_PWRON_TAP_MASK)*/
    #define STD_NIC_TAP_MASK       DIS_TAP_CAP_MASK
         
#define CONT_CONFIG_REG_ADDR    12
    #define EN_HW_RESET_MASK       0x2  /* BIT_1 */
    #define WAIT_AT_PWUP_MASK      0x1  /* BIT_0 */
    
#define STATUS_DISC_REG_ADDR    13
    #define WDTE_DISC_BPN_MASK      0x01    //BIT_0 /* 1 when wdt expired -> TAP, 0 - Bypass */
    #define STD_NIC_ON_MASK         0x02    //BIT_1
    #define DIS_DISC_CAP_MASK       0x04    //BIT_2 /* TAP Cap is disable*/
    #define DFLT_PWRON_DISC_MASK    0x08    //BIT_3
    #define DISC_OFF_MASK           0x10    //BIT_4
    #define DISC_FLAG_MASK          0x20    //BIT_5
    #define TPL2_FLAG_MASK          0x40    //BIT_6
    #define STD_NIC_DISC_MASK       DIS_DISC_CAP_MASK



#define VER_REG_ADDR               0x1
    #define BP_FW_VER_A0         0xa0
    #define BP_FW_VER_A1         0xa1
    #define INT_VER_MASK           0xf0
    #define EXT_VER_MASK           0xf
    /* */
    #define PXG2BPI_VER            0x0 
    #define PXG2TBPI_VER           0x1
    #define PXE2TBPI_VER           0x2 
    #define PXG4BPFI_VER           0x4 
    #define BP_FW_EXT_VER7         0x6
    #define BP_FW_EXT_VER8         0x8

    #define OLD_IF_VER              -1
    
#define CMND_REG_ADDR              10     /* 1010b */
#define WDT_REG_ADDR               4
#define TMRL_REG_ADDR              2
#define TMRH_REG_ADDR              3


/* NEW_FW */
#define WDT_INTERVAL               1   //5     //8
#define WDT_CMND_INTERVAL          50 
#define CMND_INTERVAL              100  /* usec */
#define PULSE_TIME                 100  

/* OLD_FW */
#define INIT_CMND_INTERVAL         40
#define PULSE_INTERVAL             5
#define WDT_TIME_CNT               3

/* Intel Commands */

#define CMND_OFF_INT               0xf
#define PWROFF_BYPASS_ON_INT       0x5
#define BYPASS_ON_INT              0x6
#define DIS_BYPASS_CAP_INT         0x4
#define RESET_WDT_INT              0x1

/* Intel timing */

#define BYPASS_DELAY_INT           4     /* msec */
#define CMND_INTERVAL_INT          2     /* msec */
             
/* Silicom Commands */
#define CMND_ON                    0x4
#define CMND_OFF                   0x2 
#define BYPASS_ON                  0xa
#define BYPASS_OFF                 0x8
#define PWROFF_BYPASS_ON           0xe
#define PWROFF_BYPASS_OFF          0xc
#define BP_WAIT_AT_PWUP_EN        0x80    
#define BP_WAIT_AT_PWUP_DIS       0x81    
#define BP_HW_RESET_EN             0x82    
#define BP_HW_RESET_DIS            0x83    
#define STD_NIC_ON                0x84  
#define STD_NIC_OFF                0x86  
#define DISC_ON           0x85    
#define DISC_OFF          0x8a    
#define DISC_STATE_PWRON  0x87    
#define DIS_DISC_CAP      0x88    
#define EN_DISC_CAP       0x89    


#define WDT_ON                     0x10                /* 0x1f (11111) - max*/
#define TIMEOUT_UNIT               100
#define TIMEOUT_UNIT_INT           4000
#define TIMEOUT_UNIT_OLDFW         500


#define TIMEOUT_MAX_STEP           15
#define TIMEOUT_MAX_STEP_OLDFW     128
#define WDT_TIMEOUT_MAX            3276800           /*  msec */
#define WDT_AUTO_MIN_INT           500
#define WDT_TIMEOUT_MAX_OLDFW      64000              /*  msec */
#define WDT_TIMEOUT_DEF        TIMEOUT_UNIT
#define WDT_OFF                    0x6
#define WDT_RELOAD                 0x9
#define RESET_CONT                 0x20
#define DIS_BYPASS_CAP             0x22
#define EN_BYPASS_CAP              0x24
#define BYPASS_STATE_PWRON         0x26
#define NORMAL_STATE_PWRON         0x28
#define BYPASS_STATE_PWROFF        0x27
#define NORMAL_STATE_PWROFF        0x29
#define TAP_ON                     0xb
#define TAP_OFF                    0x9
#define TAP_STATE_PWRON            0x2a
#define DIS_TAP_CAP                0x2c
#define EN_TAP_CAP                 0x2e
#define TPL2_ON                    0x8c
#define TPL2_OFF                   0x8b

#define BYPASS_CAP_DELAY           21     /* msec */
#define DFLT_PWRON_DELAY           10     /* msec */
#define LATCH_DELAY                13     /* msec */
#define EEPROM_WR_DELAY             8     /* msec */

#define BP_LINK_MON_DELAY          4 /* sec */

#define BP_FW_EXT_VER0                 0xa0
#define BP_FW_EXT_VER1                 0xa1
#define BP_FW_EXT_VER2                0xb1 


#define  BP_OK        0
#define  BP_NOT_CAP  -1
#define WDT_STATUS_EXP -2
#define WDT_STATUS_UNKNOWN -1
#define WDT_STATUS_EN 1
#define WDT_STATUS_DIS 0

#define E1000_CTRL_SDP0_SHIFT 18
#define E1000_CTRL_EXT_SDP6_SHIFT 6



#define IF_NAME "eth"
#ifndef usec_delay
#define usec_delay(x) udelay(x)
#endif
#ifndef msec_delay_bp
#define msec_delay_bp(x)	do { \
            int  i; \
            if(in_interrupt()) { \
                   for(i = 0; i < 1000; i++) \
                   {                     \
                      udelay(x) ;        \
                   }                     \
			} else { \
				msleep(x); \
			} } while(0)

#endif
#ifndef isdigit
#define isdigit(c) (c >= '0' && c <= '9')
#endif
__inline static int atoi( char **s) 
{
    int i = 0;
    while (isdigit(**s))
        i = i*10 + *((*s)++) - '0';
    return i;
}

struct pfs_unit {
    struct proc_dir_entry *proc_entry;
    char proc_name[32];
} ;

struct bypass_pfs {
    char dir_name[32];
    struct proc_dir_entry *bypass_entry;
    struct pfs_unit bypass_info; 
    struct pfs_unit bypass_slave;  
    struct pfs_unit bypass_caps;   
    struct pfs_unit wd_set_caps;   
    struct pfs_unit bypass;     
    struct pfs_unit bypass_change; 
    struct pfs_unit bypass_wd;     
    struct pfs_unit wd_expire_time;
    struct pfs_unit reset_bypass_wd;   
    struct pfs_unit dis_bypass; 
    struct pfs_unit bypass_pwup; 
    struct pfs_unit bypass_pwoff; 
    struct pfs_unit std_nic;
    struct pfs_unit tap;
    struct pfs_unit dis_tap;
    struct pfs_unit tap_pwup;
    struct pfs_unit tap_change;
    struct pfs_unit wd_exp_mode; 
    struct pfs_unit wd_autoreset;
    struct pfs_unit tpl;

}    ;

struct usr_notifier_block{
    struct usr_notifier_block *next;
    spinlock_t lock;
    int pid;
};

typedef struct _BP_DEVICE_BLOCK {
    void *dev_priv;
    char *bp_name;
    struct pci_dev    *bp_dev;
    struct pci_dev    *bp_slave;
    unsigned short    device;
    unsigned short    ifindex;
    struct proc_dir_entry *procfs_dir;
    struct bypass_pfs bypass_pfs_set;
    uint8_t           bp_status_un;
    int               wdt_status;
    int               bypass_timer_interval ;
    uint8_t           tx_disable;
    unsigned long     bypass_wdt_on_time;
    uint32_t          bp_caps;
    uint32_t          bp_caps_ex;
    int               bp_ctl_flag;
    uint8_t           bp_fw_ver;
    int        bp_ext_ver;
    struct timer_list bp_timer;
    int               bp_tpl_flag;
    struct timer_list bp_tpl_timer;
    uint32_t          reset_time;
    atomic_t          wdt_busy;
    unsigned long     bp_event_state;
    struct notifier_block *bp_chain;
    struct usr_notifier_block *usr_bp_chain;
    rwlock_t usr_notifier_lock;
    int               notif_pending;
    int usr_notif;
    struct semaphore bypass_lock;
    spinlock_t bypass_wr_lock;

         
}BP_DEVICE_BLOCK, *PBP_DEVICE_BLOCK;

int set_dis_bypass_fn(PBP_DEVICE_BLOCK pbp_device_block, int dis_param);
int reset_bypass_wd_timer_fn(PBP_DEVICE_BLOCK pbp_device_block);
int get_wd_expire_time_fn(PBP_DEVICE_BLOCK pbp_device_block, int *time_left);
int get_bypass_wd_fn(PBP_DEVICE_BLOCK pbp_device_block, int *timeout);
int set_bypass_wd_fn(PBP_DEVICE_BLOCK pbp_device_block, int timeout);
int get_bypass_change_fn(PBP_DEVICE_BLOCK pbp_device_block);
int get_bypass_fn (PBP_DEVICE_BLOCK pbp_device_block);
int set_bypass_fn (PBP_DEVICE_BLOCK pbp_device_block, int bypass_mode);
int get_wd_set_caps_fn(PBP_DEVICE_BLOCK pbp_device_block);
int get_bypass_caps_fn (PBP_DEVICE_BLOCK pbp_device_block);
int is_bypass_fn(PBP_DEVICE_BLOCK pbp_device_block);
int get_dis_bypass_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_two_port_link_fn(PBP_DEVICE_BLOCK pbp_device_block, int link_mode);
int get_two_port_link_fn(PBP_DEVICE_BLOCK pbp_device_block);
int zero_set_fn(PBP_DEVICE_BLOCK pbp_device_block) ;
int get_std_nic_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_std_nic_fn(PBP_DEVICE_BLOCK pbp_device_block, int nic_mode);
int set_bypass_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block, int bypass_mode);
int get_bypass_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_bypass_pwoff_fn(PBP_DEVICE_BLOCK pbp_device_block, int bypass_mode);
int get_bypass_pwoff_fn(PBP_DEVICE_BLOCK pbp_device_block);
int bypass_fw_ver(PBP_DEVICE_BLOCK pbp_device_block);
void bypass_caps_init (PBP_DEVICE_BLOCK pbp_device_block);
int set_tap_fn (PBP_DEVICE_BLOCK pbp_device_block, int tap_mode);
int get_tap_fn (PBP_DEVICE_BLOCK pbp_device_block);
int get_tap_change_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_dis_tap_fn(PBP_DEVICE_BLOCK pbp_device_block, int dis_param);
int get_dis_tap_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_tap_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block, int tap_mode);
int get_tap_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_wd_exp_mode_fn(PBP_DEVICE_BLOCK pbp_device_block, int param);
int get_wd_exp_mode_fn(PBP_DEVICE_BLOCK pbp_device_block);
int bypass_ioctl(void *bp_arg, PBP_DEVICE_BLOCK pbp_device_block);
int bypass_off_init(PBP_DEVICE_BLOCK pbp_device_block);
int wdt_time_left(PBP_DEVICE_BLOCK pbp_device_block);
void remove_bypass_wd_auto(PBP_DEVICE_BLOCK pbp_device_block);
int init_bypass_wd_auto(PBP_DEVICE_BLOCK pbp_device_block);
int reset_cont (PBP_DEVICE_BLOCK pbp_device_block);

int set_wd_autoreset_fn(PBP_DEVICE_BLOCK pbp_device_block, int param);
int get_wd_autoreset_fn(PBP_DEVICE_BLOCK pbp_device_block);

int set_disc_fn (PBP_DEVICE_BLOCK pbp_device_block, int tap_mode);
int get_disc_fn (PBP_DEVICE_BLOCK pbp_device_block);
int get_disc_change_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_dis_disc_fn(PBP_DEVICE_BLOCK pbp_device_block, int dis_param);
int get_dis_disc_fn(PBP_DEVICE_BLOCK pbp_device_block);
int set_disc_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block, int tap_mode);
int get_disc_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block);


int bypass_status(PBP_DEVICE_BLOCK pbp_device_block);
void *get_bp_master_port_fn(PBP_DEVICE_BLOCK pbp_device_block);
int init_bypass_tpl_auto(PBP_DEVICE_BLOCK pbp_device_block);
void remove_bypass_tpl_auto(PBP_DEVICE_BLOCK pbp_device_block);
#ifdef PMC_FIX_FLAG
int set_bp_wait_at_pwup_fn (PBP_DEVICE_BLOCK pbp_device_block, int tap_mode);
int get_bp_wait_at_pwup_fn (PBP_DEVICE_BLOCK pbp_device_block);
int set_bp_hw_reset_fn (PBP_DEVICE_BLOCK pbp_device_block, int tap_mode);
int get_bp_hw_reset_fn (PBP_DEVICE_BLOCK pbp_device_block);
#endif /*PMC_FIX_FLAG*/
int set_tpl_fn (PBP_DEVICE_BLOCK pbp_device_block, int tpl_mode);
int get_tpl_fn (PBP_DEVICE_BLOCK pbp_device_block);
int tpl2_flag_status(PBP_DEVICE_BLOCK pbp_device_block);
#endif    /* BYPASS_H*/


