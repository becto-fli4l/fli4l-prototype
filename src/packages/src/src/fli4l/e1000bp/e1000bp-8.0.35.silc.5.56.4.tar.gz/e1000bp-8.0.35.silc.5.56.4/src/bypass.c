/******************************************************************************/
/*                                                                            */
/* Copyright (c) 2004-2007 Silicom, Ltd                                       */
/* All rights reserved.                                                       */
/*                                                                            */
/* This program is free software; you can redistribute it and/or modify       */
/* it under the terms of the GNU General Public License as published by       */
/* the Free Software Foundation, located in the file LICENSE.                 */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
#include "e1000.h"

#ifdef BYPASS_SUPPORT

/* OLD API */

void data_pulse(PBP_DEVICE_BLOCK pbp_device_block, unsigned char value)
{

    unsigned int value32 =0;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;
#ifdef BP_SYNC_FLAG
    unsigned long flags;
#endif


    wdt_time_left(pbp_device_block);
#ifdef BP_SYNC_FLAG
    spin_lock_irqsave(&pbp_device_block->bypass_wr_lock, flags);
#else
    atomic_set(&pbp_device_block->wdt_busy,1);
#endif

    value32 = E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT);

    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((value32 | 
                                                 CTRL_EXT_MDIO_DIR|
                                                 CTRL_EXT_MCLK_DIR)&~(CTRL_EXT_MDIO_DATA|CTRL_EXT_MCLK_DATA)));
    usec_delay(CMND_INTERVAL);

    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((value32 | 
                                                 CTRL_EXT_MDIO_DIR|
                                                 CTRL_EXT_MCLK_DIR| 
                                                 CTRL_EXT_MDIO_DATA)&~CTRL_EXT_MCLK_DATA));

    usec_delay(CMND_INTERVAL);
    while (value) {
        E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, value32|
                           CTRL_EXT_MDIO_DIR|
                           CTRL_EXT_MCLK_DIR|
                           CTRL_EXT_MDIO_DATA|
                           CTRL_EXT_MCLK_DATA);
        usec_delay(PULSE_INTERVAL);
        E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((value32 | 
                                                     CTRL_EXT_MDIO_DIR|
                                                     CTRL_EXT_MCLK_DIR| 
                                                     CTRL_EXT_MDIO_DATA)&~CTRL_EXT_MCLK_DATA));
        usec_delay(PULSE_INTERVAL);
        value--;

    }
    usec_delay(CMND_INTERVAL-PULSE_INTERVAL);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((value32 | 
                                                 CTRL_EXT_MDIO_DIR|
                                                 CTRL_EXT_MCLK_DIR)&~(CTRL_EXT_MDIO_DATA|CTRL_EXT_MCLK_DATA)));
    usec_delay(WDT_TIME_CNT);
    if (pbp_device_block->wdt_status==WDT_STATUS_EN)
        pbp_device_block->bypass_wdt_on_time=jiffies;
#ifdef BP_SYNC_FLAG
    spin_unlock_irqrestore(&pbp_device_block->bypass_wr_lock, flags);
#else
    atomic_set(&pbp_device_block->wdt_busy,0);  
#endif
}



int send_wdt_pulse(PBP_DEVICE_BLOCK pbp_device_block)
{
    unsigned int value32 =0;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;

    if ((atomic_read(&pbp_device_block->wdt_busy))==1)
        return -1;
    wdt_time_left(pbp_device_block);

    value32 = E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT);


    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, value32 |     /* 1 */
                       CTRL_EXT_MCLK_DIR | 
                       CTRL_EXT_MCLK_DATA);
    usec_delay(PULSE_INTERVAL);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((value32 |     /* 0 */
                                                 CTRL_EXT_MCLK_DIR)&~CTRL_EXT_MCLK_DATA));
    if (pbp_device_block->wdt_status==WDT_STATUS_EN)
        pbp_device_block->bypass_wdt_on_time=jiffies;
    return 0;
}

void send_bypass_clear_pulse(struct e1000_adapter *adapter, unsigned int value){
    uint32_t ctrl_ext=0;

    ctrl_ext = E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext |     /* 0 */
                                                 E1000_CTRL_EXT_SDP6_DIR)&~E1000_CTRL_EXT_SDP6_DATA));

    usec_delay(PULSE_INTERVAL);
    while (value) {
        E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ctrl_ext |     /* 1 */
                           E1000_CTRL_EXT_SDP6_DIR | 
                           E1000_CTRL_EXT_SDP6_DATA);
        usec_delay(PULSE_INTERVAL);
        value--;
    }
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext |     /* 0 */
                                                 E1000_CTRL_EXT_SDP6_DIR)&~E1000_CTRL_EXT_SDP6_DATA));
    usec_delay(PULSE_INTERVAL);
}



/* NEW API */
static void write_pulse(PBP_DEVICE_BLOCK pbp_device_block, 
                        unsigned int ctrl_ext ,
                        unsigned char value, 
                        unsigned char len){
    unsigned char ctrl_val=0;
    unsigned int i=len;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;

    while (i--) {

        ctrl_val=(value>>i) & 0x1;
        if (ctrl_val) {
            /* To start management : MCLK 1, MDIO 1, output*/
            E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, (ctrl_ext | 
                                                        CTRL_EXT_MCLK_DIR|
                                                        CTRL_EXT_MDIO_DIR|
                                                        CTRL_EXT_MDIO_DATA | CTRL_EXT_MCLK_DATA));

            /*usec_delay*/usec_delay(PULSE_TIME);
            E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                         CTRL_EXT_MCLK_DIR|
                                                         CTRL_EXT_MDIO_DIR|CTRL_EXT_MDIO_DATA)&~(CTRL_EXT_MCLK_DATA)));

            /*usec_delay*/usec_delay(PULSE_TIME);

        } else {

            E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                         CTRL_EXT_MCLK_DIR|
                                                         CTRL_EXT_MDIO_DIR|CTRL_EXT_MCLK_DATA)&~(CTRL_EXT_MDIO_DATA)));
            /*usec_delay*/usec_delay(PULSE_TIME);
            E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                         CTRL_EXT_MCLK_DIR|
                                                         CTRL_EXT_MDIO_DIR)&~(CTRL_EXT_MCLK_DATA|CTRL_EXT_MDIO_DATA)));

            /*usec_delay*/usec_delay(PULSE_TIME);
        } 

    }
}

static int read_pulse(PBP_DEVICE_BLOCK pbp_device_block, unsigned int ctrl_ext ,unsigned char len){
    unsigned char ctrl_val=0;
    unsigned int i=len;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;

    while (i--) {
        E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                     CTRL_EXT_MCLK_DIR)&~(CTRL_EXT_MDIO_DIR | CTRL_EXT_MCLK_DATA)));

        usec_delay(PULSE_TIME);
        E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                     CTRL_EXT_MCLK_DIR|
                                                     CTRL_EXT_MCLK_DATA)&~(CTRL_EXT_MDIO_DIR)));

        ctrl_ext = E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT);
        usec_delay(PULSE_TIME);
        if (ctrl_ext & CTRL_EXT_MDIO_DATA)
            ctrl_val |= 1<<i;
    }

    return ctrl_val;
}

static void write_reg(PBP_DEVICE_BLOCK pbp_device_block, unsigned char value, unsigned char addr){
    uint32_t ctrl_ext=0;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;
#ifdef BP_SYNC_FLAG
    unsigned long flags;
#endif
#ifdef BYPASS_DEBUG_LEVEL
    struct timeval tv, tv_end;
#endif

#ifdef BP_SYNC_FLAG
    spin_lock_irqsave(&pbp_device_block->bypass_wr_lock, flags);
#else
    atomic_set(&pbp_device_block->wdt_busy,1);
#endif
#ifdef BYPASS_DEBUG_LEVEL
    do_gettimeofday(&tv);
#endif

    ctrl_ext = E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR |
                                                 CTRL_EXT_MDIO_DIR )&~(CTRL_EXT_MDIO_DATA|CTRL_EXT_MCLK_DATA)));
    usec_delay(CMND_INTERVAL);


    /*send sync cmd*/
    write_pulse(pbp_device_block,ctrl_ext,SYNC_CMD_VAL,SYNC_CMD_LEN);
    /*send wr cmd*/
    write_pulse(pbp_device_block,ctrl_ext,WR_CMD_VAL,WR_CMD_LEN);
    write_pulse(pbp_device_block,ctrl_ext,addr,ADDR_CMD_LEN);

    /*write data*/
    write_pulse(pbp_device_block,ctrl_ext,value,WR_DATA_LEN);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR |
                                                 CTRL_EXT_MDIO_DIR )&~(CTRL_EXT_MDIO_DATA|CTRL_EXT_MCLK_DATA)));
    usec_delay(CMND_INTERVAL);
#ifdef BYPASS_DEBUG_LEVEL
    do_gettimeofday(&tv_end);

    if (tv_end.tv_usec>tv.tv_usec) {
        printk("write duration is %lu\n", tv_end.tv_usec-tv.tv_usec);
    } else printk("write duration is %lu\n", ~tv.tv_usec+tv_end.tv_usec);
#endif
#ifdef BP_SYNC_FLAG
    spin_unlock_irqrestore(&pbp_device_block->bypass_wr_lock, flags);
#else
    atomic_set(&pbp_device_block->wdt_busy,0);
#endif
}


static void write_data(PBP_DEVICE_BLOCK pbp_device_block, unsigned char value){
    write_reg(pbp_device_block, value, CMND_REG_ADDR);
}

static int read_reg(PBP_DEVICE_BLOCK pbp_device_block, unsigned char addr){
    uint32_t ctrl_ext=0, ctrl_value=0;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;
#ifdef BP_SYNC_FLAG
    unsigned long flags;
#endif

#ifdef BYPASS_DEBUG_LEVEL
    struct timeval tv, tv_end;
#endif
#ifdef BP_SYNC_FLAG
    spin_lock_irqsave(&pbp_device_block->bypass_wr_lock, flags);
#else
    atomic_set(&pbp_device_block->wdt_busy,1);
#endif
#ifdef BYPASS_DEBUG_LEVEL
    do_gettimeofday(&tv);
#endif  
    ctrl_ext = E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR |
                                                 CTRL_EXT_MDIO_DIR)&~(CTRL_EXT_MDIO_DATA|CTRL_EXT_MCLK_DATA)));
    usec_delay(CMND_INTERVAL);
    /*send sync cmd*/
    write_pulse(pbp_device_block,ctrl_ext,SYNC_CMD_VAL,SYNC_CMD_LEN);
    /*send rd cmd*/
    write_pulse(pbp_device_block,ctrl_ext,RD_CMD_VAL,RD_CMD_LEN);
    /*send addr*/
    write_pulse(pbp_device_block,ctrl_ext,addr, ADDR_CMD_LEN);
    /*read data*/
    /* zero */
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR|CTRL_EXT_MCLK_DATA)&~(CTRL_EXT_MDIO_DIR|CTRL_EXT_MDIO_DATA)));
    usec_delay(PULSE_TIME);
    ctrl_value= read_pulse(pbp_device_block,ctrl_ext,RD_DATA_LEN);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR |
                                                 CTRL_EXT_MDIO_DIR)&~(CTRL_EXT_MDIO_DATA|CTRL_EXT_MCLK_DATA)));

    usec_delay(CMND_INTERVAL);     
#ifdef BYPASS_DEBUG_LEVEL
    do_gettimeofday(&tv_end);
    if (tv_end.tv_usec>tv.tv_usec) {
        printk("reg %x val %x read duration is %lu\n", addr, ctrl_value, tv_end.tv_usec-tv.tv_usec);
    } else printk("reg %x val %x read duration is %lu\n",addr, ctrl_value, ~tv.tv_usec+tv_end.tv_usec);
#endif
#ifdef BP_SYNC_FLAG
    spin_unlock_irqrestore(&pbp_device_block->bypass_wr_lock, flags);
#else
    atomic_set(&pbp_device_block->wdt_busy,0); 
#endif
    return ctrl_value;
}

static int wdt_pulse(PBP_DEVICE_BLOCK pbp_device_block){
    uint32_t ctrl_ext=0;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;
#ifdef BP_SYNC_FLAG
    unsigned long flags;

    spin_lock_irqsave(&pbp_device_block->bypass_wr_lock, flags);
#else
    if ((atomic_read(&pbp_device_block->wdt_busy))==1)
        return -1;
#endif /*BP_SYNC_FLAG*/

    ctrl_ext = E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR |
                                                 CTRL_EXT_MDIO_DIR)&~(CTRL_EXT_MDIO_DATA|CTRL_EXT_MCLK_DATA)));

    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR|
                                                 CTRL_EXT_MDIO_DIR |
                                                 CTRL_EXT_MCLK_DATA)&~(CTRL_EXT_MDIO_DATA)));

    usec_delay(WDT_INTERVAL);

    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, ((ctrl_ext | 
                                                 CTRL_EXT_MCLK_DIR|
                                                 CTRL_EXT_MDIO_DIR)&~(CTRL_EXT_MCLK_DATA|CTRL_EXT_MDIO_DATA)));

    if ((pbp_device_block->wdt_status==WDT_STATUS_EN)&&
        (pbp_device_block->bp_ext_ver<PXG4BPFI_VER))
        pbp_device_block->bypass_wdt_on_time=jiffies;
#ifdef BP_SYNC_FLAG
    spin_unlock_irqrestore(&pbp_device_block->bypass_wr_lock, flags);
#endif
    return 0;
}  

static void *get_status_port_fn(PBP_DEVICE_BLOCK pbp_device_block) {
    struct pci_dev *pci_slave_dev=pbp_device_block->bp_slave;
    struct net_device *net_slave_dev;       

    if (is_bypass_fn(pbp_device_block)) {
        net_slave_dev=pci_get_drvdata(pci_slave_dev);
        if ((net_slave_dev)&&(netdev_priv(net_slave_dev)))
            return(void *)(netdev_priv(net_slave_dev));
    }
    return NULL;
}

void *get_bp_master_port_fn(PBP_DEVICE_BLOCK pbp_device_block) {
    struct pci_dev *pci_master_dev=pbp_device_block->bp_dev;
    struct net_device *net_master_dev;

    net_master_dev=pci_get_drvdata(pci_master_dev);

    if ((net_master_dev)&&(netdev_priv(net_master_dev)))
        return(void *)(netdev_priv(net_master_dev));

    return NULL;
}


/**************************************/
/**************INTEL API***************/
/**************************************/

static void write_data_port_int(PBP_DEVICE_BLOCK pbp_device_block, unsigned char ctrl_value){
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;
    uint32_t value;

    value = (E1000_READ_REG(&adapter->hw, E1000_CTRL));
/* Make SDP0 Pin Directonality to Output */
    value |= E1000_CTRL_SWDPIO0;
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL, value);

    value &= ~E1000_CTRL_SWDPIN0;
    value |= ((ctrl_value & 0x1) << E1000_CTRL_SDP0_SHIFT);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL, value);

    value = (E1000_READ_REG(&adapter->hw, E1000_CTRL_EXT));
/* Make SDP2 Pin Directonality to Output */
    value |=E1000_CTRL_EXT_SDP6_DIR;
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, value);

    value &= ~E1000_CTRL_EXT_SDP6_DATA;
    value |= (((ctrl_value & 0x2) >> 1) << E1000_CTRL_EXT_SDP6_SHIFT);
    E1000_WRITE_REG(&adapter->hw, E1000_CTRL_EXT, value);

}

static int write_data_int(PBP_DEVICE_BLOCK pbp_device_block, unsigned char value){
    struct e1000_adapter *adapter_b=NULL;

    if (!(adapter_b=get_status_port_fn(pbp_device_block)))
        return -1;
    atomic_set(&pbp_device_block->wdt_busy,1);
    write_data_port_int(pbp_device_block, value&0x3);
    write_data_port_int(&adapter_b->bp_device_block,((value & 0xc) >> 2));
    atomic_set(&pbp_device_block->wdt_busy,0);

    return 0;
}   

static int wdt_pulse_int(PBP_DEVICE_BLOCK pbp_device_block){

    if ((atomic_read(&pbp_device_block->wdt_busy))==1)
        return -1;

    if ((write_data_int(pbp_device_block, RESET_WDT_INT))<0)
        return -1;
    msec_delay_bp(CMND_INTERVAL_INT);
    if ((write_data_int(pbp_device_block, CMND_OFF_INT))<0)
        return -1;
    msec_delay_bp(CMND_INTERVAL_INT);

    if (pbp_device_block->wdt_status==WDT_STATUS_EN)
        pbp_device_block->bypass_wdt_on_time=jiffies;

    return 0;
}


/*************************************/
/************* COMMANDS **************/
/*************************************/


/* CMND_ON  0x4 (100)*/
int cmnd_on(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device))
            return ret;
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER)
            write_data(pbp_device_block,CMND_ON);
        else if (pbp_device_block->bp_ext_ver==OLD_IF_VER) {
            data_pulse(pbp_device_block,CMND_ON);
        } else ret=BP_NOT_CAP;
    } else ret=BP_NOT_CAP;  

    return ret;
}


/* CMND_OFF  0x2 (10)*/
int cmnd_off(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            write_data_int(pbp_device_block,CMND_OFF_INT);
            usec_delay(CMND_INTERVAL_INT);
        } else if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER)
            write_data(pbp_device_block,CMND_OFF);
        else if (pbp_device_block->bp_ext_ver==OLD_IF_VER) {
            data_pulse(pbp_device_block,CMND_OFF);
        } else ret=BP_NOT_CAP;

    } else ret=BP_NOT_CAP;  

    return ret;
}

/* BYPASS_ON (0xa)*/
int bypass_on(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&BP_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            write_data_int(pbp_device_block,BYPASS_ON_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
            pbp_device_block->bp_status_un=FALSE;
        } else if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            write_data(pbp_device_block,BYPASS_ON);
            //if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)
            msec_delay_bp(LATCH_DELAY);
        } else if (pbp_device_block->bp_ext_ver==OLD_IF_VER) {
            data_pulse(pbp_device_block,BYPASS_ON);
        } else ret=BP_NOT_CAP;
    } else ret= BP_NOT_CAP;
    return ret;
}

/* BYPASS_OFF (0x8 111)*/
int bypass_off(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&BP_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            write_data_int(pbp_device_block,DIS_BYPASS_CAP_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
            write_data_int(pbp_device_block,PWROFF_BYPASS_ON_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
            pbp_device_block->bp_status_un=0;
        } else if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            write_data(pbp_device_block,BYPASS_OFF);
            //if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)
            msec_delay_bp(LATCH_DELAY);
        } else if (pbp_device_block->bp_ext_ver==OLD_IF_VER) {
            data_pulse(pbp_device_block,BYPASS_OFF);
        } else ret=BP_NOT_CAP;
    } else ret= BP_NOT_CAP;
    return ret;
}

/* TAP_OFF (0x9)*/
int tap_off(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;
    if ((pbp_device_block->bp_caps&TAP_CAP)&&(pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)) {
        write_data(pbp_device_block,TAP_OFF);
        msec_delay_bp(LATCH_DELAY);
    } else  ret=BP_NOT_CAP;
    return ret;
}

/* TAP_ON (0xb)*/
int tap_on(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;
    if ((pbp_device_block->bp_caps&TAP_CAP)&&(pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)) {
        write_data(pbp_device_block,TAP_ON);
        msec_delay_bp(LATCH_DELAY);
    } else  ret=BP_NOT_CAP;
    return ret;
}

/* DISC_OFF (0x9)*/
int disc_off(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;
    if ((pbp_device_block->bp_caps&DISC_CAP)&&(pbp_device_block->bp_ext_ver>=0x8)) {
        write_data(pbp_device_block,DISC_OFF);
        msec_delay_bp(LATCH_DELAY);
    } else  ret=BP_NOT_CAP;
    return ret;
}

/* DISC_ON (0xb)*/
int disc_on(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;
    if ((pbp_device_block->bp_caps&DISC_CAP)&&(pbp_device_block->bp_ext_ver>=0x8)) {
        write_data(pbp_device_block,/*DISC_ON*/0x85);
        msec_delay_bp(LATCH_DELAY);
    } else  ret=BP_NOT_CAP;
    return ret;
}


/*TWO_PORT_LINK_HW_EN (0xe)*/
int tpl_hw_on (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0, ctrl=0;
    struct e1000_adapter *adapter_b=NULL;

    if (pbp_device_block->bp_caps_ex&TPL2_CAP_EX) {
	cmnd_on(pbp_device_block);
        write_data(pbp_device_block,TPL2_ON);
        msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
	cmnd_off(pbp_device_block);
        return ret;
    }

    if ((TPL_IF_SERIES(pbp_device_block->device))
        &&(adapter_b=get_status_port_fn(pbp_device_block))) {
#if 0
        if (pbp_device_block->bp_ext_ver==OLD_IF_VER)
            data_pulse(pbp_device_block,TPL_ON);
        if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
            write_data(pbp_device_block,TPL_ON);
        else if ((pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)&&(adapter_b=get_status_port_fn(pbp_device_block))) {
            ctrl = E1000_READ_REG(&adapter_b->hw, E1000_CTRL);
            E1000_WRITE_REG(&adapter_b->hw, E1000_CTRL, ((ctrl|E1000_CTRL_SWDPIO0)&~E1000_CTRL_SWDPIN0));
        } else ret=BP_NOT_CAP;
#endif
        ctrl = E1000_READ_REG(&adapter_b->hw, E1000_CTRL);
        E1000_WRITE_REG(&adapter_b->hw, E1000_CTRL, ((ctrl|E1000_CTRL_SWDPIO0)&~E1000_CTRL_SWDPIN0));
    } else ret=BP_NOT_CAP;
    return ret;
}


/*TWO_PORT_LINK_HW_DIS (0xc)*/
int tpl_hw_off (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0, ctrl=0;
    struct e1000_adapter *adapter_b=NULL;

    if (pbp_device_block->bp_caps_ex&TPL2_CAP_EX) {
	cmnd_on(pbp_device_block);
        write_data(pbp_device_block,TPL2_OFF);
        msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
	cmnd_off(pbp_device_block);
        return ret;
    }
    if ((TPL_IF_SERIES(pbp_device_block->device))
        &&(adapter_b=get_status_port_fn(pbp_device_block))) {
#if 0
        if (pbp_device_block->bp_ext_ver==OLD_IF_VER)
            data_pulse(pbp_device_block,TPL_OFF);
        if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
            write_data(pbp_device_block,TPL_OFF);
        else if ((pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)&&(adapter_b=get_status_port_fn(pbp_device_block))) {
            ctrl = E1000_READ_REG(&adapter_b->hw, E1000_CTRL);
            E1000_WRITE_REG(&adapter_b->hw, E1000_CTRL, (ctrl|E1000_CTRL_SWDPIO0|E1000_CTRL_SWDPIN0));
        } else ret=BP_NOT_CAP;
#endif
        ctrl = E1000_READ_REG(&adapter_b->hw, E1000_CTRL);
        E1000_WRITE_REG(&adapter_b->hw, E1000_CTRL, (ctrl|E1000_CTRL_SWDPIO0|E1000_CTRL_SWDPIN0));


    } else ret=BP_NOT_CAP;
    return ret;
}


/* WDT_OFF (0x6 110)*/
int wdt_off(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            bypass_off(pbp_device_block);
        } else if (pbp_device_block->bp_ext_ver>=PXG4BPFI_VER) {
            write_data(pbp_device_block,WDT_OFF);
        } else {
            if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER)
                write_data(pbp_device_block,WDT_OFF);
            else
                data_pulse(pbp_device_block,WDT_OFF);
        }
        pbp_device_block->wdt_status=WDT_STATUS_DIS;
    } else ret=BP_NOT_CAP;
    return ret;
}

/* WDT_ON (0x10)*/
/***Global***/
static unsigned int 
wdt_val_array[]={1000, 1500, 2000, 3000, 4000, 8000, 16000, 32000, 0} ;

int wdt_on(PBP_DEVICE_BLOCK pbp_device_block, unsigned int timeout){

    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        unsigned int pulse=0, temp_value=0, temp_cnt=0;
        pbp_device_block->wdt_status=0;     

        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            for (;wdt_val_array[temp_cnt];temp_cnt++)
                if (timeout<=wdt_val_array[temp_cnt])
                    break;

            if (!wdt_val_array[temp_cnt])
                temp_cnt--;

            timeout=wdt_val_array[temp_cnt];
            temp_cnt+=0x7;

            write_data_int(pbp_device_block,DIS_BYPASS_CAP_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
            pbp_device_block->bp_status_un=0;
            write_data_int(pbp_device_block,temp_cnt);
            pbp_device_block->bypass_wdt_on_time=jiffies;
            msec_delay_bp(CMND_INTERVAL_INT);
            pbp_device_block->bypass_timer_interval=timeout;  
        } else {
            timeout=(timeout<TIMEOUT_UNIT?TIMEOUT_UNIT:(timeout>WDT_TIMEOUT_MAX?WDT_TIMEOUT_MAX:timeout));
            temp_value=timeout/100;

            while ((temp_value>>=1))
                temp_cnt++;
            if (timeout > ((1<<temp_cnt)*100))
                temp_cnt++;

            pbp_device_block->bypass_wdt_on_time=jiffies;
            pulse=(WDT_ON | temp_cnt);
            if (pbp_device_block->bp_ext_ver==OLD_IF_VER)
                data_pulse(pbp_device_block,pulse);
            else
                write_data(pbp_device_block,pulse);
            pbp_device_block->bypass_timer_interval=(1<<temp_cnt)*100;
        }
        pbp_device_block->wdt_status=WDT_STATUS_EN;
        return 0;
    }
    return BP_NOT_CAP;
}

/* SET_TX  (non-Bypass command :)) */
static int set_tx (PBP_DEVICE_BLOCK pbp_device_block, int tx_state){
    int ret=0, ctrl=0;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;

    if (pbp_device_block->bp_caps&TX_CTL_CAP) {
        if (adapter->hw.phy.media_type == e1000_media_type_copper) {
            if (tx_state) {
                uint16_t mii_reg;
                e1000_read_phy_reg(&adapter->hw, PHY_CONTROL, &mii_reg);
                if (mii_reg & MII_CR_POWER_DOWN){
                    e1000_write_phy_reg(&adapter->hw, PHY_CONTROL, mii_reg&~MII_CR_POWER_DOWN);
                }
                /*e1000_phy_reset(&adapter->hw);*/
            } else {
                uint16_t mii_reg;
                e1000_read_phy_reg(&adapter->hw, PHY_CONTROL, &mii_reg);
                mii_reg |= MII_CR_POWER_DOWN;
                e1000_write_phy_reg(&adapter->hw, PHY_CONTROL, mii_reg);
            }
        } else {
            ctrl = E1000_READ_REG(&adapter->hw, E1000_CTRL);
            if (!tx_state) {
                E1000_BP_WRITE_REG(&adapter->hw, E1000_CTRL,(ctrl|E1000_CTRL_SWDPIO0|E1000_CTRL_SWDPIN0));
            } else {
                E1000_BP_WRITE_REG(&adapter->hw, E1000_CTRL, ((ctrl|E1000_CTRL_SWDPIO0)&~E1000_CTRL_SWDPIN0));
                if (!PEGF_IF_SERIES(pbp_device_block->device))
                    E1000_BP_WRITE_REG(&adapter->hw, E1000_CTRL, 
                                       (ctrl&~(E1000_CTRL_SWDPIN0|E1000_CTRL_SWDPIO0)));
            }
        }
    } else ret=BP_NOT_CAP;

    return ret;
}


/*RESET_CONT 0x20 */
int reset_cont (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;
    if (INTEL_IF_SERIES(pbp_device_block->device))
        return BP_NOT_CAP;
    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER)
            write_data(pbp_device_block,RESET_CONT);
        else if (pbp_device_block->bp_ext_ver==OLD_IF_VER) {
            data_pulse(pbp_device_block,RESET_CONT);
        } else ret=BP_NOT_CAP;
    } else ret=BP_NOT_CAP;
    return ret;
}

/*DIS_BYPASS_CAP 0x22 */
int dis_bypass_cap(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&BP_DIS_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            write_data_int(pbp_device_block,DIS_BYPASS_CAP_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
        } else if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            if (!(pbp_device_block->bp_caps&(TAP_CAP|DISC_CAP))) {
                write_data(pbp_device_block,BYPASS_OFF);
                msec_delay_bp(LATCH_DELAY);
            }
            write_data(pbp_device_block,DIS_BYPASS_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
        } else {
            data_pulse(pbp_device_block,BYPASS_OFF);
            data_pulse(pbp_device_block,PWROFF_BYPASS_OFF); 
        }


        return BP_OK;
    }
    return BP_NOT_CAP;
}


/*EN_BYPASS_CAP 0x24 */
int en_bypass_cap(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&BP_DIS_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            write_data_int(pbp_device_block,PWROFF_BYPASS_ON_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
        } else
            if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {

            write_data(pbp_device_block,EN_BYPASS_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
            return BP_OK;
        } else {
            data_pulse(pbp_device_block,PWROFF_BYPASS_ON);

        }

        return BP_OK;
    }
    return BP_NOT_CAP;
}

/* BYPASS_STATE_PWRON 0x26*/
int bypass_state_pwron(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&BP_PWUP_CTL_CAP) {
        write_data(pbp_device_block,BYPASS_STATE_PWRON);
        if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
            msec_delay_bp(DFLT_PWRON_DELAY);
        else msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
        return BP_OK;
    }
    return BP_NOT_CAP;
}

/* NORMAL_STATE_PWRON 0x28*/
int normal_state_pwron(PBP_DEVICE_BLOCK pbp_device_block){
    if ((pbp_device_block->bp_caps&BP_PWUP_CTL_CAP)||(pbp_device_block->bp_caps&TAP_PWUP_CTL_CAP)) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            write_data(pbp_device_block,NORMAL_STATE_PWRON);
            if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
                msec_delay_bp(DFLT_PWRON_DELAY);
            else msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

/* BYPASS_STATE_PWROFF 0x27*/
int bypass_state_pwroff(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&BP_PWOFF_CTL_CAP) {
        write_data(pbp_device_block,BYPASS_STATE_PWROFF);
        msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
        return BP_OK;
    }
    return BP_NOT_CAP;
}

/* NORMAL_STATE_PWRON 0x29*/
int normal_state_pwroff(PBP_DEVICE_BLOCK pbp_device_block){
    if ((pbp_device_block->bp_caps&BP_PWOFF_CTL_CAP)) {
        write_data(pbp_device_block,NORMAL_STATE_PWROFF);
        msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
        return BP_OK;
    }
    return BP_NOT_CAP;
}


/*TAP_STATE_PWRON 0x2a*/
int tap_state_pwron(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TAP_PWUP_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            write_data(pbp_device_block,TAP_STATE_PWRON);
            msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

/*DIS_TAP_CAP 0x2c*/
int dis_tap_cap(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TAP_DIS_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            write_data(pbp_device_block,DIS_TAP_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}


/*EN_TAP_CAP 0x2e*/
int en_tap_cap(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TAP_DIS_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            write_data(pbp_device_block,EN_TAP_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

/*DISC_STATE_PWRON 0x2a*/
int disc_state_pwron(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&DISC_PWUP_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8) {
            write_data(pbp_device_block,DISC_STATE_PWRON);
            msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

/*DIS_DISC_CAP 0x2c*/
int dis_disc_cap(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&DISC_DIS_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8) {
            write_data(pbp_device_block,DIS_DISC_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}


/*EN_TAP_CAP 0x2e*/
int en_disc_cap(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&DISC_DIS_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8) {
            write_data(pbp_device_block,EN_DISC_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}



int std_nic_on(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&STD_NIC_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            write_data_int(pbp_device_block,DIS_BYPASS_CAP_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
            pbp_device_block->bp_status_un=0;
            return BP_OK;
        }
        if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER8) {
            write_data(pbp_device_block,STD_NIC_ON);
            msec_delay_bp(BYPASS_CAP_DELAY);
            return BP_OK;
        }

        wdt_off(pbp_device_block);

        if (pbp_device_block->bp_caps&BP_CAP) {
            write_data(pbp_device_block,BYPASS_OFF);
            msec_delay_bp(LATCH_DELAY);
        }

        if (pbp_device_block->bp_caps&TAP_CAP) {
            write_data(pbp_device_block,TAP_OFF);
            msec_delay_bp(LATCH_DELAY);
        }
#if 0
        write_data(pbp_device_block,NORMAL_STATE_PWRON);
        if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
            msec_delay_bp(DFLT_PWRON_DELAY);
        else msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
#endif

        if (pbp_device_block->bp_caps&BP_DIS_CAP) {
            write_data(pbp_device_block,DIS_BYPASS_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
        }

        if (pbp_device_block->bp_caps&TAP_DIS_CAP) {
            write_data(pbp_device_block,DIS_TAP_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);

        }

        return BP_OK;
    }
    return BP_NOT_CAP;
}

int std_nic_off(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&STD_NIC_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            write_data_int(pbp_device_block,PWROFF_BYPASS_ON_INT);
            msec_delay_bp(BYPASS_DELAY_INT);
            return BP_OK;
        }
        if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER8) {
            write_data(pbp_device_block,STD_NIC_OFF);
            msec_delay_bp(BYPASS_CAP_DELAY);
            return BP_OK;
        }

#if 0

        if (pbp_device_block->bp_caps&TAP_PWUP_CTL_CAP) {
            write_data(pbp_device_block,TAP_STATE_PWRON);
            msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
        }

        if (pbp_device_block->bp_caps&BP_PWUP_CTL_CAP) {
            write_data(pbp_device_block,BYPASS_STATE_PWRON);
            if (pbp_device_block->bp_ext_ver>PXG2BPI_VER)
                msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);
            else
                msec_delay_bp(DFLT_PWRON_DELAY);
        }
#endif

        if (pbp_device_block->bp_caps&TAP_DIS_CAP) {
            write_data(pbp_device_block,EN_TAP_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
        }

        if (pbp_device_block->bp_caps&DISC_DIS_CAP) {
            write_data(pbp_device_block,EN_DISC_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
        }


        if (pbp_device_block->bp_caps&BP_DIS_CAP) {
            write_data(pbp_device_block,EN_BYPASS_CAP);
            msec_delay_bp(BYPASS_CAP_DELAY);
        }

        return BP_OK;
    }
    return BP_NOT_CAP;
}



int wdt_time_left (PBP_DEVICE_BLOCK pbp_device_block)
{

    //unsigned long curr_time=((long long)(jiffies*1000))/HZ, delta_time=0,wdt_on_time=((long long)(pbp_device_block->bypass_wdt_on_time*1000))/HZ;
    unsigned long curr_time=jiffies, delta_time=0, wdt_on_time=pbp_device_block->bypass_wdt_on_time, delta_time_msec=0;
    int time_left=0;

    switch (pbp_device_block->wdt_status) {
    case WDT_STATUS_DIS:
        time_left=0;
        break;
    case WDT_STATUS_EN:
        delta_time=(curr_time>=wdt_on_time)?(curr_time-wdt_on_time):(~wdt_on_time+curr_time);
        delta_time_msec=jiffies_to_msecs(delta_time);
        time_left= pbp_device_block->bypass_timer_interval-delta_time_msec;
        if (time_left<0) {
            time_left=-1;
            pbp_device_block->wdt_status=WDT_STATUS_EXP;
        }
        break;
    case WDT_STATUS_EXP:
        time_left=-1;
        break;
    }

    return time_left;
}


int wdt_timer(PBP_DEVICE_BLOCK pbp_device_block, int *time_left){
    int ret=0;
    if (pbp_device_block->bp_caps&WD_CTL_CAP) {

        if (pbp_device_block->bp_ext_ver>=PXG4BPFI_VER) {
            if (pbp_device_block->wdt_status==WDT_STATUS_EN) {
                u_int32_t wdt_lo=0, wdt_hi=0;

                if ((read_reg(pbp_device_block,STATUS_REG_ADDR))&WD_EXP_FLAG_MASK)
                    *time_left=-1;
                else {
                    wdt_lo=read_reg(pbp_device_block,TMRL_REG_ADDR);
                    wdt_hi=read_reg(pbp_device_block,TMRH_REG_ADDR);

                    *time_left=((((wdt_hi&0xff)<<8)|(wdt_lo&0xff)))*100;
                }
            } else
                *time_left=0; /* WDT is disabled */
        } else {
            if (pbp_device_block->wdt_status==WDT_STATUS_UNKNOWN)
                ret=BP_NOT_CAP;
            else
                *time_left=wdt_time_left(pbp_device_block);
        } 

    } else ret=BP_NOT_CAP;
    return ret;
}

static int wdt_timer_reload(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if ((pbp_device_block->bp_caps&WD_CTL_CAP)&&
        (pbp_device_block->wdt_status!=WDT_STATUS_UNKNOWN)) {
        if (pbp_device_block->wdt_status==WDT_STATUS_DIS)
            return 0;
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER)
            ret= wdt_pulse(pbp_device_block);
        else if (INTEL_IF_SERIES(pbp_device_block->device))
            ret=wdt_pulse_int(pbp_device_block);
        else  ret=send_wdt_pulse(pbp_device_block);
        if (ret==-1)
            mod_timer(&pbp_device_block->bp_timer, jiffies+1);
        return 1;
    }
    return BP_NOT_CAP; 
}


static void wd_reset_timer(unsigned long param){
    PBP_DEVICE_BLOCK pbp_device_block= (PBP_DEVICE_BLOCK) param;

    wdt_timer_reload(pbp_device_block); 

    if (pbp_device_block->reset_time) {
        mod_timer(&pbp_device_block->bp_timer, jiffies+(HZ*pbp_device_block->reset_time)/1000);
    }
}

int wdt_exp_mode(PBP_DEVICE_BLOCK pbp_device_block, int mode){
    uint32_t status_reg=0, status_reg1=0;

    if ((pbp_device_block->bp_caps&(TAP_STATUS_CAP|DISC_CAP))&&
        (pbp_device_block->bp_caps&BP_CAP)) {
        if (pbp_device_block->bp_ext_ver>=PXE2TBPI_VER) {

            if ((pbp_device_block->bp_ext_ver>=0x8)&&
                (mode==2)&& 
                (pbp_device_block->bp_caps&DISC_CAP)) {
                status_reg1=read_reg(pbp_device_block,STATUS_DISC_REG_ADDR);
                if (!(status_reg1&WDTE_DISC_BPN_MASK))
                    write_reg(pbp_device_block,status_reg1 | WDTE_DISC_BPN_MASK, STATUS_DISC_REG_ADDR);
                return BP_OK;
            }
        }
        status_reg=read_reg(pbp_device_block,STATUS_TAP_REG_ADDR);

        if ((mode==0)&&(pbp_device_block->bp_caps&BP_CAP)) {
            if (pbp_device_block->bp_ext_ver>=0x8) {
                status_reg1=read_reg(pbp_device_block,STATUS_DISC_REG_ADDR);
                if (status_reg1&WDTE_DISC_BPN_MASK)
                    write_reg(pbp_device_block,status_reg1 & ~WDTE_DISC_BPN_MASK, STATUS_DISC_REG_ADDR);
            }
            if (status_reg&WDTE_TAP_BPN_MASK)
                write_reg(pbp_device_block,status_reg & ~WDTE_TAP_BPN_MASK, STATUS_TAP_REG_ADDR);
            return BP_OK;

        } else if ((mode==1)&&(pbp_device_block->bp_caps&TAP_CAP)){
                 if (!(status_reg&WDTE_TAP_BPN_MASK)) 
        	    write_reg(pbp_device_block,status_reg | WDTE_TAP_BPN_MASK, STATUS_TAP_REG_ADDR);
            /*else return BP_NOT_CAP;*/
            return BP_OK;
        }

    }
    return BP_NOT_CAP;
}

    #ifdef PMC_FIX_FLAG
/*WAIT_AT_PWRUP 0x80   */
int bp_wait_at_pwup_en(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER8) {
            write_data(pbp_device_block,BP_WAIT_AT_PWUP_EN);
            msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);

            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

/*DIS_WAIT_AT_PWRUP       0x81 */
int bp_wait_at_pwup_dis(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {

        if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER8) {
            write_data(pbp_device_block,BP_WAIT_AT_PWUP_DIS);
            msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);

            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

/*EN_HW_RESET  0x82   */

int bp_hw_reset_en(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER8) {
            write_data(pbp_device_block,BP_HW_RESET_EN);
            msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);

            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

/*DIS_HW_RESET             0x83   */

int bp_hw_reset_dis(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER8) {
            write_data(pbp_device_block,BP_HW_RESET_DIS);
            msec_delay_bp(LATCH_DELAY+EEPROM_WR_DELAY);

            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

    #endif /*PMC_FIX_FLAG*/


/**********************************************/
/**************READ STATUS*********************/
/**********************************************/

int bypass_fw_ver(PBP_DEVICE_BLOCK pbp_device_block){

    if (is_bypass_fn(pbp_device_block))
        return((read_reg(pbp_device_block,VER_REG_ADDR)));
    else return BP_NOT_CAP;
}
int bypass_sign_check(PBP_DEVICE_BLOCK pbp_device_block){

    if (is_bypass_fn(pbp_device_block))
        return(((read_reg(pbp_device_block,PIC_SIGN_REG_ADDR))==PIC_SIGN_VALUE)?1:0);
    else return BP_NOT_CAP;
}


/* SET_STATUS (non-Bypass command :)) */
static int tx_status (PBP_DEVICE_BLOCK pbp_device_block){
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;

    if (pbp_device_block->bp_caps&TX_CTL_CAP) {
        int ctrl=0;
        if (adapter->hw.phy.media_type == e1000_media_type_copper) {
            uint16_t mii_reg;
            e1000_read_phy_reg(&adapter->hw, PHY_CONTROL, &mii_reg);
            if (mii_reg & MII_CR_POWER_DOWN)
                return 0;

            else
                return 1;
        } else {

            ctrl = E1000_READ_REG(&adapter->hw, E1000_CTRL);
            if (ctrl&E1000_CTRL_SWDPIN0)
                return 0;
            return 1;
        }
    }
    return BP_NOT_CAP;
} 
int bypass_from_last_read(PBP_DEVICE_BLOCK pbp_device_block){
    uint32_t ctrl_ext=0;
    struct e1000_adapter *adapter_b=NULL;

    if ((pbp_device_block->bp_caps&SW_CTL_CAP)&&(adapter_b=get_status_port_fn(pbp_device_block))) {
        ctrl_ext = E1000_READ_REG(&adapter_b->hw, E1000_CTRL_EXT);
        E1000_WRITE_REG(&adapter_b->hw, E1000_CTRL_EXT, ( ctrl_ext & ~E1000_CTRL_EXT_SDP7_DIR));
        ctrl_ext = E1000_READ_REG(&adapter_b->hw, E1000_CTRL_EXT);
        if (ctrl_ext&E1000_CTRL_EXT_SDP7_DATA)
            return 0;
        return 1;
    } else return BP_NOT_CAP;
}

int bypass_status_clear(PBP_DEVICE_BLOCK pbp_device_block){
    struct e1000_adapter *adapter_b=NULL;

    if ((pbp_device_block->bp_caps&SW_CTL_CAP)&&(adapter_b=get_status_port_fn(pbp_device_block))) {

        send_bypass_clear_pulse(adapter_b, 1);
        return 0;
    } else
        return BP_NOT_CAP;
}

int bypass_flag_status(PBP_DEVICE_BLOCK pbp_device_block){

    if ((pbp_device_block->bp_caps&BP_CAP)) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            return((((read_reg(pbp_device_block,STATUS_REG_ADDR)) & BYPASS_FLAG_MASK)==BYPASS_FLAG_MASK)?1:0);
        }
    }
    return BP_NOT_CAP;
}

int bypass_flag_status_clear(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&BP_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            uint32_t status_reg=0;
            status_reg=read_reg(pbp_device_block,STATUS_REG_ADDR);
            write_reg(pbp_device_block,status_reg & ~BYPASS_FLAG_MASK, STATUS_REG_ADDR);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}


int bypass_change_status(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=BP_NOT_CAP;

    if (pbp_device_block->bp_caps&BP_STATUS_CHANGE_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8) {
            ret=bypass_flag_status(pbp_device_block);
            bypass_flag_status_clear(pbp_device_block);
        } else if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            ret=bypass_flag_status(pbp_device_block);
            bypass_flag_status_clear(pbp_device_block);
        } else {
            ret=bypass_from_last_read(pbp_device_block);
            bypass_status_clear(pbp_device_block);
        }
    }
    return ret;
}



int bypass_off_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&BP_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            return((((read_reg(pbp_device_block,STATUS_REG_ADDR)) & BYPASS_OFF_MASK)==BYPASS_OFF_MASK)?1:0);
        }
    }
    return BP_NOT_CAP;
}   

int bypass_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&BP_CAP) {
        struct e1000_adapter *adapter_b=NULL;

        if (!(adapter_b=get_status_port_fn(pbp_device_block)))
            return BP_NOT_CAP;

        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            if (!pbp_device_block->bp_status_un)
                return(((E1000_READ_REG(&adapter_b->hw, E1000_CTRL_EXT)) & E1000_CTRL_EXT_SDP7_DATA)!=0?1:0);
            else return BP_NOT_CAP;
        }
        if (pbp_device_block->bp_ext_ver>=0x8) {
            return(((E1000_READ_REG(&adapter_b->hw, E1000_CTRL_EXT)) & E1000_CTRL_EXT_SDP7_DATA)!=0?0:1);
        } else
            if (adapter_b->hw.phy.media_type == e1000_media_type_copper)
            return(((E1000_READ_REG(&adapter_b->hw, E1000_CTRL)) & E1000_CTRL_SWDPIN1)!=0?1:0);
        else {
            if ((bypass_status_clear(pbp_device_block))>=0)
                return(bypass_from_last_read(pbp_device_block));
        }    
    }
    return BP_NOT_CAP;
}


int default_pwron_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_caps&BP_PWUP_CTL_CAP) {
            if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
                return((((read_reg(pbp_device_block,STATUS_REG_ADDR)) & DFLT_PWRON_MASK)==DFLT_PWRON_MASK)?0:1);
            }
        } /*else if ((!pbp_device_block->bp_caps&BP_DIS_CAP)&&
                   (pbp_device_block->bp_caps&BP_PWUP_ON_CAP))
            return 1;*/
    }
    return BP_NOT_CAP;
}

static int default_pwroff_status(PBP_DEVICE_BLOCK pbp_device_block){

    /*if ((!(pbp_device_block->bp_caps&BP_DIS_CAP))&&
        (pbp_device_block->bp_caps&BP_PWOFF_ON_CAP))
        return 1;*/
    if ((pbp_device_block->bp_caps&SW_CTL_CAP)&&(pbp_device_block->bp_caps&BP_PWOFF_CTL_CAP)) {
        return((((read_reg(pbp_device_block,STATUS_REG_ADDR)) & DFLT_PWROFF_MASK)==DFLT_PWROFF_MASK)?0:1);
    }
    return BP_NOT_CAP;
} 

int dis_bypass_cap_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&BP_DIS_STATUS_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            return((((read_reg(pbp_device_block,STATUS_REG_ADDR)) & DIS_BYPASS_CAP_MASK)==DIS_BYPASS_CAP_MASK)?1:0);
        }
    }
    return BP_NOT_CAP;
}


int cmd_en_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            return((((read_reg(pbp_device_block,STATUS_REG_ADDR)) & CMND_EN_MASK)==CMND_EN_MASK)?1:0);
        }
    }
    return BP_NOT_CAP;
}

int wdt_en_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            return((((read_reg(pbp_device_block,STATUS_REG_ADDR)) & WDT_EN_MASK)==WDT_EN_MASK)?1:0);
        }
    }
    return BP_NOT_CAP;
}

int wdt_programmed(PBP_DEVICE_BLOCK pbp_device_block, int *timeout){
    int ret=0;
    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {

            if ((read_reg(pbp_device_block,STATUS_REG_ADDR))&WDT_EN_MASK) {
                u8 wdt_val;
                wdt_val=read_reg(pbp_device_block,WDT_REG_ADDR);
                *timeout=  (1<<wdt_val)*100;
            } else *timeout=0;
        } else {
            int curr_wdt_status= pbp_device_block->wdt_status;

            if (curr_wdt_status==WDT_STATUS_UNKNOWN)
                *timeout=-1;
            else
                *timeout=curr_wdt_status==0?0:pbp_device_block->bypass_timer_interval;
        };
    } else ret=BP_NOT_CAP;
    return ret;
}

int bypass_support(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            ret=((((read_reg(pbp_device_block,PRODUCT_CAP_REG_ADDR)) & BYPASS_SUPPORT_MASK)==BYPASS_SUPPORT_MASK)?1:0);
        } else if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
            ret=1;
    } else ret=BP_NOT_CAP;
    return ret;
}

int tap_support(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            ret=((((read_reg(pbp_device_block,PRODUCT_CAP_REG_ADDR)) & TAP_SUPPORT_MASK)==TAP_SUPPORT_MASK)?1:0);
        } else if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
            ret=0;
    } else ret=BP_NOT_CAP;
    return ret;
}

int disc_support(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8) {
            ret=((((read_reg(pbp_device_block,PRODUCT_CAP_REG_ADDR)) & DISC_SUPPORT_MASK)==DISC_SUPPORT_MASK)?1:0);
        } else ret=0;
    } else ret=BP_NOT_CAP;
    return ret;
}

int get_bp_prod_caps(PBP_DEVICE_BLOCK pbp_device_block){
    if ((pbp_device_block->bp_caps&SW_CTL_CAP)&&
        (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER))
        return(read_reg(pbp_device_block,PRODUCT_CAP_REG_ADDR));
    return BP_NOT_CAP;

}


int normal_support(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=BP_NOT_CAP;

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            ret=((((read_reg(pbp_device_block,PRODUCT_CAP_REG_ADDR)) & NORMAL_UNSUPPORT_MASK)==NORMAL_UNSUPPORT_MASK)?0:1);
        } else
            ret=1;
    };
    return ret;
}


int tap_flag_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&TAP_STATUS_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)
            return((((read_reg(pbp_device_block,STATUS_TAP_REG_ADDR)) & TAP_FLAG_MASK)==TAP_FLAG_MASK)?1:0);

    }
    return BP_NOT_CAP;
}

int tap_flag_status_clear(PBP_DEVICE_BLOCK pbp_device_block){
    uint32_t status_reg=0;
    if (pbp_device_block->bp_caps&TAP_STATUS_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            status_reg=read_reg(pbp_device_block,STATUS_TAP_REG_ADDR);
            write_reg(pbp_device_block,status_reg & ~TAP_FLAG_MASK, STATUS_TAP_REG_ADDR);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

int tap_change_status(PBP_DEVICE_BLOCK pbp_device_block){
    int ret= BP_NOT_CAP;
    if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
        if (pbp_device_block->bp_caps&TAP_CAP) {
            if (pbp_device_block->bp_caps&BP_CAP) {
                ret=tap_flag_status(pbp_device_block);
                tap_flag_status_clear(pbp_device_block);
            } else {
                ret=bypass_from_last_read(pbp_device_block);
                bypass_status_clear(pbp_device_block);
            }
        }
    }
    return ret;
}


int tap_off_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TAP_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)
            return((((read_reg(pbp_device_block,STATUS_TAP_REG_ADDR)) & TAP_OFF_MASK)==TAP_OFF_MASK)?1:0);
    }
    return BP_NOT_CAP;
}


int tap_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TAP_CAP) {
        struct e1000_adapter *adapter_b=NULL;

        if (!(adapter_b=get_status_port_fn(pbp_device_block)))
            return BP_NOT_CAP;
        if (pbp_device_block->bp_ext_ver>=0x8) {
            return(((E1000_READ_REG(&adapter_b->hw, E1000_CTRL_EXT)) & E1000_CTRL_EXT_SDP6_DATA)!=0?0:1);
        } else
            if (adapter_b->hw.phy.media_type == e1000_media_type_copper)
            return(((E1000_READ_REG(&adapter_b->hw, E1000_CTRL)) & E1000_CTRL_SWDPIN0)!=0?1:0);
        else {
            if ((bypass_status_clear(pbp_device_block))>=0)
                return(bypass_from_last_read(pbp_device_block));
        }   

    }
    return BP_NOT_CAP;
}

int default_pwron_tap_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TAP_PWUP_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)
            return((((read_reg(pbp_device_block,STATUS_TAP_REG_ADDR)) & DFLT_PWRON_TAP_MASK)==DFLT_PWRON_TAP_MASK)?1:0);
    }
    return BP_NOT_CAP;
}

int dis_tap_cap_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TAP_DIS_CAP) {
        if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER)
            return((((read_reg(pbp_device_block,STATUS_TAP_REG_ADDR)) & DIS_TAP_CAP_MASK)==DIS_TAP_CAP_MASK)?1:0);
    }
    return BP_NOT_CAP;
}

int disc_flag_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&DISC_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8)
            return((((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & DISC_FLAG_MASK)==DISC_FLAG_MASK)?1:0);

    }
    return BP_NOT_CAP;
}

int disc_flag_status_clear(PBP_DEVICE_BLOCK pbp_device_block){
    uint32_t status_reg=0;
    if (pbp_device_block->bp_caps&DISC_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8) {
            status_reg=read_reg(pbp_device_block,STATUS_DISC_REG_ADDR);
            write_reg(pbp_device_block,status_reg & ~DISC_FLAG_MASK, STATUS_DISC_REG_ADDR);
            return BP_OK;
        }
    }
    return BP_NOT_CAP;
}

int disc_change_status(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=BP_NOT_CAP;
    if (pbp_device_block->bp_caps&DISC_CAP) {
        ret=disc_flag_status(pbp_device_block);
        disc_flag_status_clear(pbp_device_block);
        return ret;
    }
    return BP_NOT_CAP;
}

int disc_off_status(PBP_DEVICE_BLOCK pbp_device_block){
    struct e1000_adapter *adapter_b=NULL, *adapter=NULL;

    if (pbp_device_block->bp_caps&DISC_CAP) {
        if (!(adapter_b=get_status_port_fn(pbp_device_block)))
            return BP_NOT_CAP;
        if(DISCF_IF_SERIES(pbp_device_block->device))
           return((((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & DISC_OFF_MASK)==DISC_OFF_MASK)?1:0);
        if (!(adapter=(struct e1000_adapter *)pbp_device_block->dev_priv))
            return BP_NOT_CAP;

        if (adapter->hw.phy.media_type == e1000_media_type_copper){
        //if (pbp_device_block->device==SILICOM_PXG2TBI_PID) {

#if 0	
            return((((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & DISC_OFF_MASK)==DISC_OFF_MASK)?1:0);
#endif
            return(((E1000_READ_REG(&adapter_b->hw, E1000_CTRL)) & E1000_CTRL_SWDPIN1)!=0?1:0);    

        } else {
            return(((E1000_READ_REG(&adapter_b->hw, E1000_CTRL_EXT)) & E1000_CTRL_EXT_SDP6_DATA)!=0?1:0);
        }
    }
    return BP_NOT_CAP;
}

int disc_status(PBP_DEVICE_BLOCK pbp_device_block){
    int ctrl=0;
    if (pbp_device_block->bp_caps&DISC_CAP) {

        if ((ctrl=disc_off_status(pbp_device_block))<0)
            return ctrl;
        return((ctrl==0)?1:0);

    }
    return BP_NOT_CAP;
}


int default_pwron_disc_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&DISC_PWUP_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8)
            return((((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & DFLT_PWRON_DISC_MASK)==DFLT_PWRON_DISC_MASK)?1:0);
    }
    return BP_NOT_CAP;
}

int dis_disc_cap_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&DIS_DISC_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8)
            return((((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & DIS_DISC_CAP_MASK)==DIS_DISC_CAP_MASK)?1:0);
    }
    return BP_NOT_CAP;
}

int wdt_exp_mode_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver<=PXG2BPI_VER)
            return 0;  /* bypass mode */
        else if (pbp_device_block->bp_ext_ver==PXG2TBPI_VER)
            return 1; /* tap mode */
        else if (pbp_device_block->bp_ext_ver>=PXE2TBPI_VER) {
            if (pbp_device_block->bp_ext_ver>=0x8) {
                if (((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & WDTE_DISC_BPN_MASK)==WDTE_DISC_BPN_MASK)
                    return 2;
            }
            return((((read_reg(pbp_device_block,STATUS_TAP_REG_ADDR)) & WDTE_TAP_BPN_MASK)==WDTE_TAP_BPN_MASK)?1:0);
        }
    }
    return BP_NOT_CAP;
}

int tpl2_flag_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps_ex&TPL2_CAP_EX) {
        return((((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & TPL2_FLAG_MASK)==TPL2_FLAG_MASK)?1:0);

    }
    return BP_NOT_CAP;
}

    
int tpl_hw_status (PBP_DEVICE_BLOCK pbp_device_block){
    struct e1000_adapter *adapter_b=NULL;

    if ((TPL_IF_SERIES(pbp_device_block->device))
        &&(adapter_b=get_status_port_fn(pbp_device_block))) {
        return((E1000_READ_REG(&adapter_b->hw, E1000_CTRL)&E1000_CTRL_SWDPIN0)!=0?1:0) ;
    }
    return BP_NOT_CAP;
}

#ifdef PMC_FIX_FLAG


int bp_wait_at_pwup_status(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8)
            return((((read_reg(pbp_device_block,CONT_CONFIG_REG_ADDR)) & WAIT_AT_PWUP_MASK)==WAIT_AT_PWUP_MASK)?1:0);
    }
    return BP_NOT_CAP;
}

int bp_hw_reset_status(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        if (pbp_device_block->bp_ext_ver>=0x8)
            return((((read_reg(pbp_device_block,CONT_CONFIG_REG_ADDR)) & EN_HW_RESET_MASK)==EN_HW_RESET_MASK)?1:0);
    }
    return 0;
}
    #endif /*PMC_FIX_FLAG*/

int std_nic_status(PBP_DEVICE_BLOCK pbp_device_block){
    int status_val=0;

    if (pbp_device_block->bp_caps&STD_NIC_CAP) {
        if (INTEL_IF_SERIES(pbp_device_block->device))
            return BP_NOT_CAP;

        if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER8) {
            return((((read_reg(pbp_device_block,STATUS_DISC_REG_ADDR)) & STD_NIC_ON_MASK)==STD_NIC_ON_MASK)?1:0);
        }
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            if (pbp_device_block->bp_caps&BP_CAP) {
                status_val=read_reg(pbp_device_block,STATUS_REG_ADDR);
                if (((!(status_val&WDT_EN_MASK))&& ((status_val & STD_NIC_MASK)==STD_NIC_MASK)))
                    status_val=1;
                else
                    return 0;
            }
            if (pbp_device_block->bp_caps&TAP_DIS_STATUS_CAP) {
                status_val=read_reg(pbp_device_block,STATUS_TAP_REG_ADDR);
                if ((status_val & STD_NIC_TAP_MASK)==STD_NIC_TAP_MASK)
                    status_val=1;
                else
                    return 0;
            } else if (pbp_device_block->bp_caps&TAP_CAP) {
                if (!(tap_status(pbp_device_block)))
                    status_val=1;
                else
                    return 0;
            }
            if (pbp_device_block->bp_caps&TAP_CAP) {
                if ((disc_off_status(pbp_device_block)))
                    status_val=1;
                else
                    return 0; 
            }

#if 0
            if (pbp_device_block->bp_caps&DISC_CAP) {
                status_val=read_reg(pbp_device_block,STATUS_DISC_REG_ADDR);
                if ((status_val & STD_NIC_DISC_MASK)==STD_NIC_DISC_MASK)
                    status_val=1;
                else
                    return 0;
            }
#endif

            return status_val;
        }
    }
    return BP_NOT_CAP;
}  




/******************************************************/
/**************SW_INIT*********************************/
/******************************************************/

void bypass_caps_init (PBP_DEVICE_BLOCK pbp_device_block){

#ifdef BYPASS_DEBUG
    int ret=0;
    if (!(INTEL_IF_SERIES(adapter->bp_device_block.device))) {
        ret=read_reg(pbp_device_block,VER_REG_ADDR) ;
        printk("VER_REG reg1=%x\n",ret);
        ret=read_reg(pbp_device_block,PRODUCT_CAP_REG_ADDR) ;
        printk("PRODUCT_CAP reg=%x\n",ret);
        ret=read_reg(pbp_device_block,STATUS_TAP_REG_ADDR) ;
        printk("STATUS_TAP reg1=%x\n",ret);
        ret=read_reg(pbp_device_block,0x7) ;
        printk("SIG_REG reg1=%x\n",ret);
        ret=read_reg(pbp_device_block,STATUS_REG_ADDR);
        printk("STATUS_REG_ADDR=%x\n",ret);
        ret=read_reg(pbp_device_block,WDT_REG_ADDR);
        printk("WDT_REG_ADDR=%x\n",ret);
        ret=read_reg(pbp_device_block,TMRL_REG_ADDR);
        printk("TMRL_REG_ADDR=%x\n",ret);
        ret=read_reg(pbp_device_block,TMRH_REG_ADDR);
        printk("TMRH_REG_ADDR=%x\n",ret);
    }
#endif    

    if (is_bypass_fn(pbp_device_block)) {
        pbp_device_block->bp_caps|=BP_PWOFF_ON_CAP;
        if (!(INTEL_IF_SERIES(pbp_device_block->device)))
            pbp_device_block->bp_caps|=TPL_CAP;


        if (INTEL_IF_SERIES(pbp_device_block->device)) {
            pbp_device_block->bp_caps|=(BP_CAP | BP_STATUS_CAP | SW_CTL_CAP |  
                                        BP_PWUP_ON_CAP |BP_PWUP_OFF_CAP | 
                                        BP_PWOFF_ON_CAP |BP_PWOFF_OFF_CAP |
                                        WD_CTL_CAP | WD_STATUS_CAP | STD_NIC_CAP |
                                        WD_TIMEOUT_CAP);
            if (((struct e1000_adapter *)(pbp_device_block->dev_priv))->hw.phy.media_type == e1000_media_type_copper)
                pbp_device_block->bp_caps|=(TX_CTL_CAP| TX_STATUS_CAP);

            pbp_device_block->bp_ext_ver=OLD_IF_VER;
            return;
        }

        pbp_device_block->bp_caps|=(TX_CTL_CAP| TX_STATUS_CAP);

        if ((pbp_device_block->bp_fw_ver==0xff)&&
            ((OLD_IF_SERIES(pbp_device_block->device)))) {

            pbp_device_block->bp_caps|=(BP_CAP | BP_STATUS_CAP | BP_STATUS_CHANGE_CAP | SW_CTL_CAP |  
                                        BP_PWUP_ON_CAP | WD_CTL_CAP | WD_STATUS_CAP | BP_PWOFF_ON_CAP |
                                        WD_TIMEOUT_CAP);

            pbp_device_block->bp_ext_ver=OLD_IF_VER;
            return; 
        }

        else {
            switch (pbp_device_block->bp_fw_ver) {
            case BP_FW_VER_A0:
            case BP_FW_VER_A1 :{ 
                    pbp_device_block->bp_ext_ver=(pbp_device_block->bp_fw_ver & EXT_VER_MASK);
                    break;
                }
            default: { 
                    if ((bypass_sign_check(pbp_device_block))!=1) {
                        pbp_device_block->bp_caps=0;
                        return;
                    }
                    pbp_device_block->bp_ext_ver=(pbp_device_block->bp_fw_ver & EXT_VER_MASK);
                }
            }
        }

        if (pbp_device_block->bp_ext_ver==PXG2BPI_VER)
            pbp_device_block->bp_caps|=(BP_CAP|BP_STATUS_CAP|BP_STATUS_CHANGE_CAP|SW_CTL_CAP|BP_DIS_CAP|BP_DIS_STATUS_CAP|
                                        BP_PWUP_ON_CAP|BP_PWUP_OFF_CAP|BP_PWUP_CTL_CAP|WD_CTL_CAP|
                                        STD_NIC_CAP|WD_STATUS_CAP|WD_TIMEOUT_CAP);
        else if (pbp_device_block->bp_ext_ver>=PXG2TBPI_VER) {
            int cap_reg;

            pbp_device_block->bp_caps|=(SW_CTL_CAP|WD_CTL_CAP|WD_STATUS_CAP|WD_TIMEOUT_CAP);
            cap_reg=get_bp_prod_caps(pbp_device_block);
            if ((cap_reg & NORMAL_UNSUPPORT_MASK)==NORMAL_UNSUPPORT_MASK)
                pbp_device_block->bp_caps|= NIC_CAP_NEG;
            else
                pbp_device_block->bp_caps|= STD_NIC_CAP;
            if ((cap_reg & BYPASS_SUPPORT_MASK)==BYPASS_SUPPORT_MASK) {
                pbp_device_block->bp_caps|=(BP_CAP|BP_STATUS_CAP|BP_STATUS_CHANGE_CAP|BP_DIS_CAP|BP_DIS_STATUS_CAP|
                                            BP_PWOFF_ON_CAP| BP_PWUP_ON_CAP|BP_PWUP_OFF_CAP|BP_PWUP_CTL_CAP);
                if (pbp_device_block->bp_ext_ver>=BP_FW_EXT_VER7)
                    pbp_device_block->bp_caps|= BP_PWOFF_OFF_CAP|BP_PWOFF_CTL_CAP;
            }
            if ((cap_reg & TAP_SUPPORT_MASK)==TAP_SUPPORT_MASK) {
                pbp_device_block->bp_caps|=(TAP_CAP|TAP_STATUS_CAP|TAP_STATUS_CHANGE_CAP|TAP_DIS_CAP|TAP_DIS_STATUS_CAP|
                                            TAP_PWUP_ON_CAP|TAP_PWUP_OFF_CAP|TAP_PWUP_CTL_CAP);
            }
            if (pbp_device_block->bp_ext_ver>=0x8) {
                if ((cap_reg & DISC_SUPPORT_MASK)==DISC_SUPPORT_MASK)
                    pbp_device_block->bp_caps|=(DISC_CAP|DISC_DIS_CAP|DISC_PWUP_CTL_CAP);
                if ((cap_reg & TPL2_SUPPORT_MASK)==TPL2_SUPPORT_MASK) {
                    pbp_device_block->bp_caps_ex|=TPL2_CAP_EX;
                    pbp_device_block->bp_tpl_flag=tpl2_flag_status(pbp_device_block);
                }
            }
        }
        if (pbp_device_block->bp_ext_ver>=PXG2BPI_VER) {
            if ((read_reg(pbp_device_block,STATUS_REG_ADDR))&WDT_EN_MASK)
                pbp_device_block->wdt_status=WDT_STATUS_EN;
            else  pbp_device_block->wdt_status=WDT_STATUS_DIS;
        }

    } else if ((((struct e1000_adapter *)(pbp_device_block->dev_priv))->hw.phy.media_type == e1000_media_type_copper)||
               P2BPFI_IF_SERIES(pbp_device_block->device))
        pbp_device_block->bp_caps|= (TX_CTL_CAP| TX_STATUS_CAP);
}


int bypass_off_init(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    if ((ret=cmnd_on(pbp_device_block))<0)
        return ret;

    if (INTEL_IF_SERIES(pbp_device_block->device))
        return(dis_bypass_cap(pbp_device_block));
    wdt_off(pbp_device_block);
    if (pbp_device_block->bp_caps&BP_CAP)
        bypass_off(pbp_device_block);
    if (pbp_device_block->bp_caps&TAP_CAP)
        tap_off(pbp_device_block);
    cmnd_off(pbp_device_block);
    return BP_OK;
}

void remove_bypass_wd_auto(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&WD_CTL_CAP)
        del_timer_sync(&pbp_device_block->bp_timer);
}

int init_bypass_wd_auto(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        init_timer(&pbp_device_block->bp_timer);
        pbp_device_block->bp_timer.function=&wd_reset_timer;
        pbp_device_block->bp_timer.data=(unsigned long)pbp_device_block;
        return 1;
    }
    return BP_NOT_CAP; 
}


static int set_bypass_wd_auto(PBP_DEVICE_BLOCK pbp_device_block, unsigned int param){
    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        if (pbp_device_block->reset_time!=param) {
            if (INTEL_IF_SERIES(pbp_device_block->device))
                pbp_device_block->reset_time=(param<WDT_AUTO_MIN_INT)?WDT_AUTO_MIN_INT:param;
            else pbp_device_block->reset_time=param;
            if (param)
                mod_timer(&pbp_device_block->bp_timer, jiffies);
        }
        return 1;
    }
    return BP_NOT_CAP; 
}

static int get_bypass_wd_auto(PBP_DEVICE_BLOCK pbp_device_block){

    if (pbp_device_block->bp_caps&WD_CTL_CAP) {
        return pbp_device_block->reset_time;
    }
    return BP_NOT_CAP; 
}

/**************************************************************/
/************************* API ********************************/
/**************************************************************/


int is_bypass_fn(PBP_DEVICE_BLOCK pbp_device_block){
    return((pbp_device_block->bp_ctl_flag==1)?1:0);
}

int get_bypass_slave_fn(PBP_DEVICE_BLOCK pbp_device_block){
    struct pci_dev *pci_slave_dev=pbp_device_block->bp_slave;
    struct net_device *net_slave_dev;

    if (is_bypass_fn(pbp_device_block)) {
        net_slave_dev=pci_get_drvdata(pci_slave_dev);
        if (net_slave_dev)
            return net_slave_dev->ifindex;
    }
    return BP_NOT_CAP;
}


int get_bypass_caps_fn (PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps==0)
        return BP_NOT_CAP;
    return pbp_device_block->bp_caps;
}

int set_bypass_fn (PBP_DEVICE_BLOCK pbp_device_block, int bypass_mode){
    int ret=0;  
    if (!(pbp_device_block->bp_caps & BP_CAP))
        return BP_NOT_CAP;

    bp_lock(pbp_device_block);
    if ((ret=cmnd_on(pbp_device_block))<0) {
        bp_unlock(pbp_device_block);
        return ret;
    }

    if (!bypass_mode)
        ret=bypass_off(pbp_device_block);
    else
        ret=bypass_on(pbp_device_block);

    cmnd_off(pbp_device_block);

    bp_unlock(pbp_device_block);

    return ret;
}

int get_bypass_fn (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;  

   // bp_lock(pbp_device_block);
    ret=bypass_status(pbp_device_block);
  //  bp_unlock(pbp_device_block);

    return ret;

}

int get_bypass_change_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;  

    bp_lock(pbp_device_block);
    ret=bypass_change_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_dis_bypass_fn(PBP_DEVICE_BLOCK pbp_device_block, int dis_param){
    int ret=0;

    if (!(pbp_device_block->bp_caps & BP_DIS_CAP))
        return BP_NOT_CAP;

    bp_lock(pbp_device_block);
    if ((ret=cmnd_on(pbp_device_block))<0)
        return ret;
    if (dis_param)
        ret=dis_bypass_cap(pbp_device_block);
    else
        ret=en_bypass_cap(pbp_device_block);
    cmnd_off(pbp_device_block);

    bp_unlock(pbp_device_block);
    return ret;
}

int get_dis_bypass_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=dis_bypass_cap_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;  

}

int set_bypass_pwoff_fn (PBP_DEVICE_BLOCK pbp_device_block, int bypass_mode){
    int ret=0;

    if (!(pbp_device_block->bp_caps & BP_PWOFF_CTL_CAP))
        return BP_NOT_CAP;

    bp_lock(pbp_device_block);
    if ((ret=cmnd_on(pbp_device_block))<0) {
        bp_unlock(pbp_device_block);
        return ret;
    }
    if (bypass_mode)
        ret=bypass_state_pwroff(pbp_device_block);
    else
        ret=normal_state_pwroff(pbp_device_block);
    cmnd_off(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;  
}

int get_bypass_pwoff_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=default_pwroff_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_bypass_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block, int bypass_mode){
    int ret=0;

    if (!(pbp_device_block->bp_caps & BP_PWUP_CTL_CAP))
        return BP_NOT_CAP;

    bp_lock(pbp_device_block);
    if ((ret=cmnd_on(pbp_device_block))<0) {
        bp_unlock(pbp_device_block);
        return ret;
    }
    if (bypass_mode)
        ret=bypass_state_pwron(pbp_device_block);
    else
        ret=normal_state_pwron(pbp_device_block);
    cmnd_off(pbp_device_block);

    bp_unlock(pbp_device_block);
    return ret;
}

int get_bypass_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=default_pwron_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_bypass_wd_fn(PBP_DEVICE_BLOCK pbp_device_block, int timeout){
    int ret=0;

    if (!(pbp_device_block->bp_caps & WD_CTL_CAP))
        return BP_NOT_CAP;

    bp_lock(pbp_device_block);
    if ((ret=cmnd_on(pbp_device_block))<0) {
        bp_unlock(pbp_device_block);
        return ret;
    }
    if (!timeout)
        ret=wdt_off(pbp_device_block);
    else {
        wdt_on(pbp_device_block,timeout);
        ret = pbp_device_block->bypass_timer_interval;
    }
    cmnd_off(pbp_device_block);
    bp_unlock(pbp_device_block);
    return ret;
}

int get_bypass_wd_fn(PBP_DEVICE_BLOCK pbp_device_block, int *timeout){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=wdt_programmed(pbp_device_block, timeout);
    bp_unlock(pbp_device_block);

    return ret;
}

int get_wd_expire_time_fn(PBP_DEVICE_BLOCK pbp_device_block, int *time_left){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=wdt_timer(pbp_device_block, time_left);
    bp_unlock(pbp_device_block);

    return ret;
}

int reset_bypass_wd_timer_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=wdt_timer_reload(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int get_wd_set_caps_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int bp_status=0;
    unsigned int step_value=TIMEOUT_MAX_STEP+1, bit_cnt=0;

    if (INTEL_IF_SERIES(pbp_device_block->device))
        return BP_NOT_CAP;

    while ((step_value>>=1))
        bit_cnt++;

    if (is_bypass_fn(pbp_device_block)) {
        bp_status= WD_STEP_COUNT_MASK(bit_cnt)|WDT_STEP_TIME|WD_MIN_TIME_MASK(TIMEOUT_UNIT/100);
    } else  bp_status=BP_NOT_CAP;

    return bp_status;
}

int set_std_nic_fn(PBP_DEVICE_BLOCK pbp_device_block, int nic_mode){
    int ret=0;
    if (!(pbp_device_block->bp_caps & STD_NIC_CAP))
        return BP_NOT_CAP;
    bp_lock(pbp_device_block);
    if ((ret=cmnd_on(pbp_device_block))<0)
        return ret;
    if (nic_mode)
        ret=std_nic_on(pbp_device_block);
    else
        ret=std_nic_off(pbp_device_block);
    cmnd_off(pbp_device_block);

    bp_unlock(pbp_device_block);
    return ret;
}

int get_std_nic_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=std_nic_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_tap_fn (PBP_DEVICE_BLOCK pbp_device_block, int tap_mode){

    if ((pbp_device_block->bp_caps & TAP_CAP)&&((cmnd_on(pbp_device_block))>=0)) {
        bp_lock(pbp_device_block);
        if (!tap_mode)
            tap_off(pbp_device_block);
        else
            tap_on(pbp_device_block);
        cmnd_off(pbp_device_block);

        bp_unlock(pbp_device_block);
        return BP_OK;
    }
    return BP_NOT_CAP;
}

int get_tap_fn (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

   // bp_lock(pbp_device_block);
    ret=tap_status(pbp_device_block);
   // bp_unlock(pbp_device_block);

    return ret;
}

int set_tap_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block, int tap_mode){
    int ret=0;

    if ((pbp_device_block->bp_caps & TAP_PWUP_CTL_CAP)&&((cmnd_on(pbp_device_block))>=0)) {
        bp_lock(pbp_device_block);
        if (tap_mode)
            ret=tap_state_pwron(pbp_device_block);
        else
            ret=normal_state_pwron(pbp_device_block);
        cmnd_off(pbp_device_block);
        bp_unlock(pbp_device_block);
    } else ret=BP_NOT_CAP;
    return ret;
}

int get_tap_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=default_pwron_tap_status(pbp_device_block);
    bp_unlock(pbp_device_block);
    return(ret==0?1:(ret<0?BP_NOT_CAP:0));
}

int get_tap_change_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block); 
    ret=tap_change_status(pbp_device_block);
    bp_unlock(pbp_device_block);
    return ret;
}

int set_dis_tap_fn(PBP_DEVICE_BLOCK pbp_device_block, int dis_param){
    int ret=0;

    if ((pbp_device_block->bp_caps & TAP_DIS_CAP)&&((cmnd_on(pbp_device_block))>=0)) {
        bp_lock(pbp_device_block); 
        if (dis_param)
            ret=dis_tap_cap(pbp_device_block);
        else
            ret=en_tap_cap(pbp_device_block);
        cmnd_off(pbp_device_block);
        bp_unlock(pbp_device_block);
        return ret;
    } else
        return BP_NOT_CAP;
}

int get_dis_tap_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block); 
    ret=dis_tap_cap_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_disc_fn (PBP_DEVICE_BLOCK pbp_device_block, int disc_mode){

    if ((pbp_device_block->bp_caps & DISC_CAP)&&((cmnd_on(pbp_device_block))>=0)) {
        bp_lock(pbp_device_block);
        if (!disc_mode)
            disc_off(pbp_device_block);
        else
            disc_on(pbp_device_block);
        cmnd_off(pbp_device_block);

        bp_unlock(pbp_device_block);
        return BP_OK;
    }
    return BP_NOT_CAP;
}

int get_disc_fn (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=disc_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_disc_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block, int disc_mode){
    int ret=0;

    if ((pbp_device_block->bp_caps & DISC_PWUP_CTL_CAP)&&((cmnd_on(pbp_device_block))>=0)) {
        bp_lock(pbp_device_block);
        if (disc_mode)
            ret=disc_state_pwron(pbp_device_block);
        else
            ret=normal_state_pwron(pbp_device_block);
        cmnd_off(pbp_device_block);
        bp_unlock(pbp_device_block);
    } else ret=BP_NOT_CAP;
    return ret;
}

int get_disc_pwup_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=default_pwron_disc_status(pbp_device_block);
    bp_unlock(pbp_device_block);
    return(ret==0?1:(ret<0?BP_NOT_CAP:0));
}

int get_disc_change_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block); 
    ret=disc_change_status(pbp_device_block);
    bp_unlock(pbp_device_block);
    return ret;
}

int set_dis_disc_fn(PBP_DEVICE_BLOCK pbp_device_block, int dis_param){
    int ret=0;

    if ((pbp_device_block->bp_caps & DISC_DIS_CAP)&&((cmnd_on(pbp_device_block))>=0)) {
        bp_lock(pbp_device_block); 
        if (dis_param)
            ret=dis_disc_cap(pbp_device_block);
        else
            ret=en_disc_cap(pbp_device_block);
        cmnd_off(pbp_device_block);
        bp_unlock(pbp_device_block);
        return ret;
    } else
        return BP_NOT_CAP;
}

int get_dis_disc_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block); 
    ret=dis_disc_cap_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int get_wd_exp_mode_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block); 
    ret=wdt_exp_mode_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_wd_exp_mode_fn(PBP_DEVICE_BLOCK pbp_device_block, int param){
    int ret=0;

    bp_lock(pbp_device_block); 
    ret=wdt_exp_mode(pbp_device_block,param);
    bp_unlock(pbp_device_block);

    return ret;
}

int get_tx_fn(PBP_DEVICE_BLOCK pbp_device_block){
    struct e1000_adapter *adapter_b=NULL;

    if ((pbp_device_block->bp_caps&TPL_CAP)&&
        (pbp_device_block->bp_ctl_flag)) {
        if ((pbp_device_block->bp_tpl_flag))
            return BP_NOT_CAP;
    } else if ((adapter_b=get_bp_master_port_fn(pbp_device_block))) {
        if ((adapter_b->bp_device_block.bp_caps&TPL_CAP)&&
            (adapter_b->bp_device_block.bp_tpl_flag))
            return BP_NOT_CAP;
    }
    return(tx_status(pbp_device_block));
}

int set_tx_fn(PBP_DEVICE_BLOCK pbp_device_block, int param){
    struct e1000_adapter *adapter_b=NULL;

    if ((pbp_device_block->bp_caps&TPL_CAP)&&
        (pbp_device_block->bp_ctl_flag)) {
        if ((pbp_device_block->bp_tpl_flag))
            return BP_NOT_CAP;
    } else if ((adapter_b=get_bp_master_port_fn(pbp_device_block))) {
        if ((adapter_b->bp_device_block.bp_caps&TPL_CAP)&&
            (adapter_b->bp_device_block.bp_tpl_flag))
            return BP_NOT_CAP;
    }
    return(set_tx(pbp_device_block,param));
}   

int reset_cont_fn (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;
    bp_lock(pbp_device_block);
    if ((ret=cmnd_on(pbp_device_block))<0) {
        bp_unlock(pbp_device_block);
        return ret;
    }
    ret=reset_cont(pbp_device_block);
    bp_unlock(pbp_device_block);
    return ret;
}

int set_wd_autoreset_fn(PBP_DEVICE_BLOCK pbp_device_block, int param){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=set_bypass_wd_auto(pbp_device_block,param);
    bp_unlock(pbp_device_block);
    return ret;
}

int get_wd_autoreset_fn(PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;
    bp_lock(pbp_device_block);
    ret=get_bypass_wd_auto(pbp_device_block);
    bp_unlock(pbp_device_block);
    return ret;
}

int get_bypass_info_fn(PBP_DEVICE_BLOCK pbp_device_block, struct bp_info *bp_info){
    if (is_bypass_fn(pbp_device_block)) {
        sprintf(bp_info->prod_name,"%s", pbp_device_block->bp_name);
        bp_info->fw_ver= pbp_device_block->bp_fw_ver;
        return 0;
    }
    return BP_NOT_CAP;
}

int get_bypass_link_status (struct e1000_adapter *adapter){
    if (adapter->hw.phy.media_type == e1000_media_type_internal_serdes) {
        return((E1000_READ_REG(&adapter->hw, E1000_CTRL)& E1000_CTRL_SWDPIN1));
    } else
        return((E1000_READ_REG(&adapter->hw, E1000_STATUS) & E1000_STATUS_LU));
}

static void bp_tpl_timer_fn(unsigned long param){
    PBP_DEVICE_BLOCK pbp_device_block= (PBP_DEVICE_BLOCK) param;
    struct e1000_adapter *adapter=(struct e1000_adapter *)pbp_device_block->dev_priv;
    struct e1000_adapter *adapter2=NULL;
    
    uint32_t link1, link2;
    adapter2=get_status_port_fn(pbp_device_block);

    if (!pbp_device_block->bp_tpl_flag) {
        set_tx(&adapter2->bp_device_block,1);
        set_tx(pbp_device_block,1);
        return;
    }
    link1 = get_bypass_link_status(adapter);

    if (adapter2) {
        link2 = get_bypass_link_status(adapter2);
        if ((link1)&&(tx_status(pbp_device_block))) {
            if ((!link2)&&(tx_status(&adapter2->bp_device_block))) {
                set_tx(pbp_device_block,0);
            } else if (!tx_status(&adapter2->bp_device_block)) {
                set_tx(&adapter2->bp_device_block,1);
            }
        } else if ((!link1)&&(tx_status(pbp_device_block))) {
            if ((link2)&&(tx_status(&adapter2->bp_device_block))) {
                set_tx(&adapter2->bp_device_block,0);
            }
        } else if ((link1)&&(!tx_status(pbp_device_block))) {
            if ((link2)&&(tx_status(&adapter2->bp_device_block))) {
                set_tx(pbp_device_block,1);
            }
        } else if ((!link1)&&(!tx_status(pbp_device_block))) {
            if ((link2)&&(tx_status(&adapter2->bp_device_block))) {
                set_tx(pbp_device_block,1);  
            }
        }
    }

    mod_timer(&pbp_device_block->bp_tpl_timer, jiffies+BP_LINK_MON_DELAY*HZ);
}


void remove_bypass_tpl_auto(PBP_DEVICE_BLOCK pbp_device_block){
    struct e1000_adapter *adapter2=NULL;
    
    if (pbp_device_block->bp_caps&SW_CTL_CAP){
        del_timer_sync(&pbp_device_block->bp_tpl_timer);
        pbp_device_block->bp_tpl_flag=0;
	adapter2=get_status_port_fn(pbp_device_block);    
	if(adapter2)
	    set_tx(&adapter2->bp_device_block,1);
	set_tx(pbp_device_block,1);
    }
    return;    
}

int init_bypass_tpl_auto(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&SW_CTL_CAP) {
        init_timer(&pbp_device_block->bp_tpl_timer);
        pbp_device_block->bp_tpl_timer.function=&bp_tpl_timer_fn;
        pbp_device_block->bp_tpl_timer.data=(unsigned long)pbp_device_block;
        return BP_OK;
    }
    return BP_NOT_CAP; 
}

int set_bypass_tpl_auto(PBP_DEVICE_BLOCK pbp_device_block, unsigned int param){
    if (pbp_device_block->bp_caps&TPL_CAP) {
        if ((param)&&(!pbp_device_block->bp_tpl_flag)) {
            pbp_device_block->bp_tpl_flag=param;
            mod_timer(&pbp_device_block->bp_tpl_timer, jiffies+1);
            return BP_OK;
        };
        if((!param)&&(pbp_device_block->bp_tpl_flag))
            remove_bypass_tpl_auto(pbp_device_block); 
        
        return BP_OK;
    }
    return BP_NOT_CAP; 
}

int get_bypass_tpl_auto(PBP_DEVICE_BLOCK pbp_device_block){
    if (pbp_device_block->bp_caps&TPL_CAP) {
        return pbp_device_block->bp_tpl_flag;
    }
    return BP_NOT_CAP; 
}

int set_tpl_fn (PBP_DEVICE_BLOCK pbp_device_block, int tpl_mode){
    struct e1000_adapter *adapter2=NULL;

    if (pbp_device_block->bp_caps&TPL_CAP) {
        if (tpl_mode) {
            if ((adapter2=get_status_port_fn(pbp_device_block)))
                set_tx_fn(&adapter2->bp_device_block,1);
            set_tx_fn(pbp_device_block,1);
        }
        if ((TPL_IF_SERIES(pbp_device_block->device))||
            (pbp_device_block->bp_caps_ex&TPL2_CAP_EX))
             {
            pbp_device_block->bp_tpl_flag=tpl_mode;
            if (!tpl_mode)
                tpl_hw_off(pbp_device_block);
            else
                tpl_hw_on(pbp_device_block);
        } else
            set_bypass_tpl_auto(pbp_device_block, tpl_mode);
        return 0;
    }
    return BP_NOT_CAP;
}

int get_tpl_fn (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=BP_NOT_CAP;
    if (pbp_device_block->bp_caps&TPL_CAP) {
        if (pbp_device_block->bp_caps_ex&TPL2_CAP_EX)
            return(tpl2_flag_status(pbp_device_block));
        ret=pbp_device_block->bp_tpl_flag;
    }
    return ret;
}

    #ifdef PMC_FIX_FLAG
int set_bp_wait_at_pwup_fn (PBP_DEVICE_BLOCK pbp_device_block, int tap_mode){

    if (pbp_device_block->bp_caps & SW_CTL_CAP) {
        bp_lock(pbp_device_block);
        cmnd_on(pbp_device_block);
        if (!tap_mode)
            bp_wait_at_pwup_dis(pbp_device_block);
        else
            bp_wait_at_pwup_en(pbp_device_block);
        cmnd_off(pbp_device_block);


        bp_unlock(pbp_device_block);
        return BP_OK;
    }
    return BP_NOT_CAP;
}

int get_bp_wait_at_pwup_fn (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=bp_wait_at_pwup_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}

int set_bp_hw_reset_fn (PBP_DEVICE_BLOCK pbp_device_block, int tap_mode){

    if (pbp_device_block->bp_caps & SW_CTL_CAP) {
        bp_lock(pbp_device_block);
        cmnd_on(pbp_device_block);

        if (!tap_mode)
            bp_hw_reset_dis(pbp_device_block);
        else
            bp_hw_reset_en(pbp_device_block);
        cmnd_off(pbp_device_block);
        bp_unlock(pbp_device_block);
        return BP_OK;
    }
    return BP_NOT_CAP;
}

int get_bp_hw_reset_fn (PBP_DEVICE_BLOCK pbp_device_block){
    int ret=0;

    bp_lock(pbp_device_block);
    ret=bp_hw_reset_status(pbp_device_block);
    bp_unlock(pbp_device_block);

    return ret;
}
    #endif  /*PMC_FIX_FLAG*/

int bypass_ioctl(void *bp_arg, PBP_DEVICE_BLOCK pbp_device_block){
    int err=0; 
    struct if_bypass *ifbp=(struct if_bypass * )bp_arg;

    switch (ifbp->cmd) {
    case IS_BYPASS :
        err=is_bypass_fn(pbp_device_block);
        break;
    case GET_BYPASS_SLAVE :
        err=get_bypass_slave_fn(pbp_device_block);
        break;
    case GET_BYPASS_CAPS :
        err=get_bypass_caps_fn(pbp_device_block);
        break;
    case SET_BYPASS :
        err=set_bypass_fn(pbp_device_block,ifbp->data);
        break;
    case GET_BYPASS :
        err=get_bypass_fn(pbp_device_block);
        break;
    case GET_BYPASS_CHANGE :
        err=get_bypass_change_fn(pbp_device_block);
        break;
    case SET_DIS_BYPASS :
        err=set_dis_bypass_fn(pbp_device_block,ifbp->data);
        break;
    case GET_DIS_BYPASS :
        err=get_dis_bypass_fn(pbp_device_block);
        break;
    case SET_BYPASS_PWOFF :
        err=set_bypass_pwoff_fn(pbp_device_block,ifbp->data);
        break;
    case GET_BYPASS_PWOFF :
        err=get_bypass_pwoff_fn(pbp_device_block);
        break;
    case SET_BYPASS_PWUP :
        err=set_bypass_pwup_fn(pbp_device_block,ifbp->data);
        break;
    case GET_BYPASS_PWUP :
        err=get_bypass_pwup_fn(pbp_device_block);
        break;
    case SET_BYPASS_WD :
        err=set_bypass_wd_fn(pbp_device_block,ifbp->data);
        break;
    case GET_BYPASS_WD :
        err=get_bypass_wd_fn(pbp_device_block,&ifbp->data);
        break;
    case GET_WD_EXPIRE_TIME :
        err=get_wd_expire_time_fn(pbp_device_block,&ifbp->data);
        break;
    case RESET_BYPASS_WD_TIMER :
        err=reset_bypass_wd_timer_fn(pbp_device_block);
        break;
    case GET_WD_SET_CAPS :
        err=get_wd_set_caps_fn(pbp_device_block);
        break;
    case SET_STD_NIC :
        err=set_std_nic_fn(pbp_device_block,ifbp->data);
        break;
    case GET_STD_NIC :
        err=get_std_nic_fn(pbp_device_block);
        break;
    case SET_TAP :
        err=set_tap_fn(pbp_device_block,ifbp->data);
        break;
    case GET_TAP :
        err=get_tap_fn(pbp_device_block);
        break;
    case GET_TAP_CHANGE :
        err=get_tap_change_fn(pbp_device_block);
        break;
    case SET_DIS_TAP :
        err=set_dis_tap_fn(pbp_device_block,ifbp->data);
        break;
    case GET_DIS_TAP :
        err=get_dis_tap_fn(pbp_device_block);
        break;
    case SET_TAP_PWUP :
        err=set_tap_pwup_fn(pbp_device_block,ifbp->data);
        break;
    case GET_TAP_PWUP :
        err=get_tap_pwup_fn(pbp_device_block);
        break;
    case SET_WD_EXP_MODE:
        err=set_wd_exp_mode_fn(pbp_device_block,ifbp->data);
        break;
    case GET_WD_EXP_MODE:
        err=get_wd_exp_mode_fn(pbp_device_block);
        break;
    case SET_TX :
        err=set_tx_fn(pbp_device_block,ifbp->data);
        break;
    case GET_TX :
        err=get_tx_fn(pbp_device_block);
        break;
    case SET_WD_AUTORESET :
        err=set_wd_autoreset_fn(pbp_device_block,ifbp->data);
        break;
    case GET_WD_AUTORESET :
        err=get_wd_autoreset_fn(pbp_device_block);
        break;
    case GET_BYPASS_INFO :{
            struct if_bypass_info *ifbp_info=(struct if_bypass_info * )bp_arg;
            err=get_bypass_info_fn(pbp_device_block,&ifbp_info->bp_info);
            break;
        }
    case SET_TPL :
        err=set_tpl_fn(pbp_device_block,ifbp->data);
        break;
    case GET_TPL :
        err=get_tpl_fn(pbp_device_block);
        break;
    case SET_DISC :
        err=set_disc_fn(pbp_device_block,ifbp->data);
        break;
    case GET_DISC :
        err=get_disc_fn(pbp_device_block);
        break;
    case GET_DISC_CHANGE :
        err=get_disc_change_fn(pbp_device_block);
        break;
    case SET_DIS_DISC :
        err=set_dis_disc_fn(pbp_device_block,ifbp->data);
        break;
    case GET_DIS_DISC :
        err=get_dis_disc_fn(pbp_device_block);
        break;
    case SET_DISC_PWUP :
        err=set_disc_pwup_fn(pbp_device_block,ifbp->data);
        break;
    case GET_DISC_PWUP :
        err=get_disc_pwup_fn(pbp_device_block);
        break;

    default:
        printk("ioctl: Unknown command!\n");
        err=-EOPNOTSUPP;
        break;
    }

    return err;
}





#endif




